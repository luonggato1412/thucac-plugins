var BASE_URL = 'https://animevietsub.best';
var BASE_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';
try { if (CONFIG_URL) BASE_URL = CONFIG_URL.replace(/\/+$/, ''); } catch (e) {}

// Cloudflare: lượt đầu trả 403 + window.location.href="/" kèm cookie, gửi lại là được.
function fetchPage(url, options) {
    if (!options) options = {};
    var headers = {
        'User-Agent': BASE_UA,
        'Accept': 'text/html,application/xhtml+xml,application/json,*/*;q=0.8',
        'Referer': BASE_URL + '/'
    };
    if (options.headers) for (var k in options.headers) headers[k] = options.headers[k];
    options.headers = headers;
    var res = null;
    for (var i = 0; i < 3; i++) {
        try {
            res = fetch(url, options);
            if (res.ok) {
                return res;
            }
        } catch (e) { res = null; }
        sleep(500);
    }
    return res || { ok: false, status: 0 };
}

function normalizeUrl(url) {
    if (!url) return '';
    if (url.indexOf('http') === 0) return url;
    if (url.indexOf('//') === 0) return 'https:' + url;
    if (url.indexOf('/') === 0) return BASE_URL + url;
    return BASE_URL + '/' + url;
}

function cleanText(t) { return t ? t.replace(/\s+/g, ' ').trim() : ''; }

// Danh sách phim (li.TPostMv) + link trang kế từ .wp-pagenavi
function parseList(doc) {
    var list = [];
    doc.select('ul.MovieList li.TPostMv, li.TPostMv').forEach(function (item) {
        var a = item.select('article.TPost > a, a[href*=/phim/]').first();
        if (!a) return;
        var link = normalizeUrl(a.attr('href'));
        var name = cleanText(item.select('.Title').first() ? item.select('.Title').first().text() : a.attr('title'));
        if (!name || !link) return;
        for (var i = 0; i < list.length; i++) if (list[i].link === link) return;
        var img = item.select('.Image img, img').first();
        var cover = img ? normalizeUrl(img.attr('src') || img.attr('data-src')) : '';
        var ep = item.select('span.mli-eps').first();
        var desc = '';
        if (ep) {
            var num = cleanText(ep.select('i').text());
            desc = num ? 'Tập ' + num : cleanText(ep.text());
            if (/HO[ÀA]N\s*T[ẤA]T/i.test(desc)) desc = 'Hoàn tất';
        }
        list.push({ name: name, link: link, cover: cover, description: desc, host: BASE_URL });
    });
    var next = doc.select('.wp-pagenavi span.current + a').first();
    return { list: list, next: next ? normalizeUrl(next.attr('href')) : null };
}

// page có thể là URL trang kế (lấy từ phân trang) hoặc số
function listPageUrl(url, page) {
    if (page && String(page).indexOf('http') === 0) return page;
    url = normalizeUrl(url);
    if (!page || page == '1') return url;
    return url.replace(/\/?$/, '/') + 'trang-' + page + '.html';
}
