load('config.js');
function execute() {
    return Response.success([
        { title: 'Anime mới cập nhật', input: BASE_URL + '/anime-moi/', script: 'gen.js' },
        { title: 'Đang chiếu', input: BASE_URL + '/danh-sach/list-dang-chieu/', script: 'gen.js' },
        { title: 'Anime bộ', input: BASE_URL + '/anime-bo/', script: 'gen.js' },
        { title: 'Anime lẻ / Movie', input: BASE_URL + '/anime-le/', script: 'gen.js' },
        { title: 'Trọn bộ', input: BASE_URL + '/danh-sach/list-tron-bo/', script: 'gen.js' },
        { title: 'Hoạt hình Trung Quốc', input: BASE_URL + '/hoat-hinh-trung-quoc/', script: 'gen.js' },
        { title: 'Sắp chiếu', input: BASE_URL + '/anime-sap-chieu/', script: 'gen.js' }
    ]);
}
