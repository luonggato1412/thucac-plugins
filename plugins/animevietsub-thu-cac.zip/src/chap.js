load('config.js');
// Trả về danh sách server cho một tập. track.js gọi /ajax/player để lấy link.
function execute(url) {
    url = normalizeUrl(url);
    var res = fetchPage(url);
    if (!res.ok) return Response.error('HTTP ' + res.status);
    var html = res.text();
    var doc = Html.parse(html);
    var filmId = (html.match(/filmInfo\.filmID\s*=\s*parseInt\('(\d+)'\)/) || url.match(/-a(\d+)\//) || [])[1];
    var epId = (html.match(/filmInfo\.episodeID\s*=\s*parseInt\('(\d+)'\)/) || url.match(/-(\d+)\.html/) || [])[1];

    var servers = [];
    doc.select('#list-server .server-group').forEach(function (g) {
        var sname = cleanText(g.select('h3.server-name').text()) || 'AnimeVsub';
        var a = null;
        g.select('a.episode-link').forEach(function (e) {
            if (!a && (e.attr('data-id') == epId || normalizeUrl(e.attr('href')) == url)) a = e;
        });
        if (a && a.attr('data-hash')) {
            servers.push({ title: sname, data: JSON.stringify({ body: 'link=' + encodeURIComponent(a.attr('data-hash')) + '&id=' + filmId, referer: url }) });
        }
    });

    // Link nhúng sẵn trong trang (dự phòng khi không lấy được hash)
    if (!servers.length) {
        var m = html.match(/PLAYER_DATA\s*=\s*(\{.*?\});/);
        if (m) {
            try {
                var pd = JSON.parse(m[1]);
                if (pd.link) servers.push({ title: 'AnimeVsub', data: JSON.stringify({ link: pd.link, playTech: pd.playTech, referer: url }) });
            } catch (e) {}
        }
    }

    // Server phụ (HDX...)
    if (epId) {
        var r = fetchPage(BASE_URL + '/ajax/player', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', 'Referer': url },
            body: 'episodeId=' + epId + '&backup=1'
        });
        if (r.ok) {
            try {
                var j = JSON.parse(r.text());
                if (j && j.html) {
                    Html.parse(j.html).select('a.btn3dsv').forEach(function (b) {
                        var id = b.attr('data-id');
                        if (id == '0') return; // DU = server chính đã có
                        servers.push({ title: cleanText(b.text()) || ('Server ' + id), data: JSON.stringify({
                            body: 'link=' + encodeURIComponent(b.attr('data-href')) + '&play=' + b.attr('data-play') + '&id=' + id + '&backuplinks=1',
                            referer: url }) });
                    });
                }
            } catch (e) {}
        }
    }
    return Response.success(servers);
}
