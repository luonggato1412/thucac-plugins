load('config.js');
function execute(url) {
    url = normalizeUrl(url).replace(/(xem-phim|tap-[^\/]+)\.html$/, '').replace(/\/?$/, '/');
    var res = fetchPage(url + 'xem-phim.html');
    if (!res.ok) return Response.error('HTTP ' + res.status);
    var doc = res.html();
    var list = [], seen = {};
    var group = doc.select('#list-server .server-group').first() || doc;
    group.select('ul.list-episode li.episode a.episode-link').forEach(function (a) {
        var href = normalizeUrl(a.attr('href'));
        if (!href || seen[href]) return;
        seen[href] = 1;
        var t = cleanText(a.attr('title')) || ('Tập ' + cleanText(a.text()));
        list.push({ name: t, url: href, host: BASE_URL });
    });
    return Response.success(list);
}
