load('config.js');
function execute(input) {
    var d = {};
    try { d = JSON.parse(input); } catch (e) { d = { link: input }; }
    var referer = d.referer || (BASE_URL + '/');
    var link = d.link, tech = d.playTech;

    if (d.body) {
        var res = fetchPage(BASE_URL + '/ajax/player', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', 'Referer': referer },
            body: d.body
        });
        if (!res.ok) return Response.error('Không lấy được link phim (HTTP ' + res.status + ')');
        var j;
        try { j = JSON.parse(res.text()); } catch (e) { return Response.error('Phản hồi player không hợp lệ'); }
        if (!j || !j.link) return Response.error('Server không trả link');
        link = j.link; tech = j.playTech;
    }

    // playTech api/all: mảng [{file,label,type}]
    if (link && typeof link !== 'string') {
        var f = link[0] && link[0].file ? link[0].file : '';
        link = f.replace('&http', 'http');
        if (link.indexOf('//') === 0) link = 'https:' + link;
    }
    if (!link) return Response.error('Không có link phim');

    var direct = /\.(m3u8|mp4)(\?|$)/i.test(link);
    return Response.success({
        data: link,
        type: direct ? 'native' : 'auto',
        headers: { 'Referer': direct ? referer : (BASE_URL + '/'), 'User-Agent': BASE_UA }
    });
}
