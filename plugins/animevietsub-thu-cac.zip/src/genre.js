load('config.js');
function execute() {
    var g = 'Hành động|hanh-dong,Phiêu lưu|phieu-luu,Hài hước|hai-huoc,Drama|drama,Fantasy|phep-thuat,Ma thuật|ma-thuat,Tình cảm|tinh-cam,Trường học|truong-hoc,Đời thường|doi-thuong,Siêu nhiên|sieu-nhien,Thể thao|the-thao,Kinh dị|kinh-di,Bí ẩn|mystery,Hồi hộp|hoi-hop,Thriller|thriller,Tâm lý|psychological,Sci-Fi|sci-fi,Mecha|mecha,Space|space,Super Power|super-power,Martial Arts|martial-arts,Samurai|samurai,Lịch sử|lich-su,Cổ trang|co-trang,Quân đội|quan-doi,Âm nhạc|am-nhac,Trò chơi|tro-choi,Harem|harem,Ecchi|ecchi,Shounen|shounen,Shoujo|shoujo,Seinen|seinen,Josei|josei,Shounen Ai|shounen-ai,Shoujo Ai|shoujo-ai,Đồng tính nam|dong-tinh-nam,Yaoi|yaoi,Yuri|yuri,Vampire|vampire,Demons|demons,Police|police,Parody|parody,Điên loạn|dien-loan,Trẻ em|tre-em,Cartoon|cartoon,Live Action|live-action,Tokusatsu|tokusatsu'.split(',');
    return Response.success(g.map(function (s) {
        var p = s.split('|');
        return { title: p[0], input: BASE_URL + '/the-loai/' + p[1] + '/', script: 'gen.js' };
    }));
}
