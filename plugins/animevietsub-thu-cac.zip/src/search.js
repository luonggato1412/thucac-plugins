load('config.js');
function execute(key, page) {
    var url = BASE_URL + '/tim-kiem/' + encodeURIComponent(key.trim()).replace(/%20/g, '+') + '/';
    var res = fetchPage(listPageUrl(url, page));
    if (!res.ok) return Response.error('Tìm kiếm lỗi (HTTP ' + res.status + ')');
    var r = parseList(res.html());
    return Response.success(r.list, r.list.length ? r.next : null);
}
