load('config.js');
function execute(url, page) {
    var res = fetchPage(listPageUrl(url, page));
    if (!res.ok) return Response.error('Không tải được danh sách (HTTP ' + res.status + ')');
    var r = parseList(res.html());
    return Response.success(r.list, r.list.length ? r.next : null);
}
