load('config.js');
function execute(url) {
    url = normalizeUrl(url).replace(/(xem-phim|tap-[^\/]+)\.html$/, '');
    var res = fetchPage(url);
    if (!res.ok) return Response.error('HTTP ' + res.status);
    var doc = res.html();
    var art = doc.select('article.TPost.Single').first() || doc;
    function txt(sel) { var e = art.select(sel).first(); return e ? cleanText(e.text()) : ''; }

    var name = txt('h1.Title');
    var sub = txt('h2.SubTitle');
    var img = art.select('.Image figure img').first();
    var cover = img ? normalizeUrl(img.attr('src')) : '';
    var desc = txt('.Description');
    var year = txt('p.Info .Date');

    var detail = [];
    if (sub) detail.push('Tên khác: ' + sub);
    if (year) detail.push('Năm: ' + year);
    var status = '', genres = [], author = '';
    doc.select('ul.InfoList li').forEach(function (li) {
        var label = cleanText(li.select('strong').text());
        var value = cleanText(li.text().replace(label, ''));
        if (label.indexOf('Thể loại') >= 0) {
            li.select('a').forEach(function (a) {
                var t = cleanText(a.text());
                if (t) genres.push({ title: t, input: normalizeUrl(a.attr('href')), script: 'gen.js' });
            });
        } else if (label.indexOf('Trạng thái') >= 0) {
            status = value; detail.push('Trạng thái: ' + value);
        } else if (label.indexOf('Studio') >= 0) {
            author = value; detail.push('Studio: ' + value);
        } else if (label.indexOf('Tập mới') >= 0 || label.indexOf('Lịch chiếu') >= 0) {
            // bỏ qua
        } else if (label && value) {
            detail.push(label + ' ' + value);
        }
    });
    var ongoing = /đang chiếu|cập nhật/i.test(status) && !/hoàn tất|full/i.test(status);
    var isMovie = genres.some(function (g) { return /anime lẻ|movie/i.test(g.title); });
    return Response.success({
        name: name, cover: cover, author: author || 'AnimeVietsub', description: desc,
        detail: detail.join('<br>'), ongoing: ongoing, genres: genres,
        suggests: genres.length ? [{ title: 'Cùng thể loại: ' + genres[genres.length - 1].title, input: genres[genres.length - 1].input, script: 'gen.js' }] : [],
        format: isMovie ? 'movie' : 'series', host: BASE_URL
    });
}
