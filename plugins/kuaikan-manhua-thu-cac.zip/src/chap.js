load("common.js");

function nuxtScript(html) {
    var i = html.indexOf("window.__NUXT__");
    if (i < 0) return null;
    var end = html.indexOf("</script>", i);
    if (end < 0) return null;
    return html.substring(i, end);
}

function evalNuxt(code) {
    try {
        var w = {};
        (new Function("window", code))(w);
        return w.__NUXT__ || null;
    } catch (e) {
        return null;
    }
}

function regexImages(html, code) {
    // Fallback when evaluation fails. Nuxt hoists the first images into function
    // parameters, so take them from the <img> tags in the body, then the rest in order.
    var out = [];
    var seen = {};
    function add(u) {
        u = u.replace(/\\u002F/g, "/").replace(/&amp;/g, "&");
        var key = u.split("?")[0];
        if (!seen[key]) { seen[key] = 1; out.push(u); }
    }
    var body = html.substring(0, html.indexOf("window.__NUXT__"));
    var re1 = /<img[^>]+(?:data-src|src)="(https?:\/\/tn\d*\.kkmh\.com\/image\/c\d+\/[^"]+)"/g, m;
    while ((m = re1.exec(body)) != null) add(m[1]);
    var re2 = /"(https?:(?:\\u002F|\/){2}tn\d*\.kkmh\.com(?:\\u002F|\/)image(?:\\u002F|\/)c\d+(?:\\u002F|\/)[^"]+)"/g;
    while ((m = re2.exec(code || "")) != null) add(m[1]);
    return out;
}

function execute(url) {
    var m = /comics\/(\d+)/.exec("" + url);
    var u = m ? HOST + "/mobile/comics/" + m[1] + "/" : "" + url;
    var html = getText(u);
    if (!html) return Response.error("Không tải được chương");
    var code = nuxtScript(html);
    var nuxt = code ? evalNuxt(code) : null;
    var d = nuxt && nuxt.data && nuxt.data[0];
    var info = d && d.comicInfo;
    var images = [];
    if (info) {
        if (info.locked === true) {
            return Response.error("Chương này trả phí hoặc dành cho VIP trên 快看漫画, plugin chỉ đọc được chương miễn phí.");
        }
        images = info.images || [];
        if (!images.length && info.comic_images) {
            for (var i = 0; i < info.comic_images.length; i++) images.push(info.comic_images[i].url || info.comic_images[i]);
        }
    } else {
        if (/"locked"\s*:\s*true|locked:!0/.test(code || "")) {
            return Response.error("Chương này trả phí hoặc dành cho VIP trên 快看漫画, plugin chỉ đọc được chương miễn phí.");
        }
        images = regexImages(html, code);
    }
    if (!images.length) return Response.error("Không tìm thấy ảnh trong chương");
    var data = [];
    for (var j = 0; j < images.length; j++) data.push(abs(images[j]));
    return Response.success(data);
}
