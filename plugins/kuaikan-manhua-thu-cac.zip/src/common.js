var HOST = "https://m.kuaikanmanhua.com";
var UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
var HEADERS = {"User-Agent": UA, "Referer": HOST + "/"};

function getJson(url) {
    var r = fetch(url, {headers: HEADERS});
    if (!r.ok) return null;
    try { return r.json(); } catch (e) { return null; }
}

function getText(url) {
    var r = fetch(url, {headers: HEADERS});
    if (!r.ok) return null;
    return r.text();
}

function abs(u) {
    if (!u) return "";
    u = "" + u;
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u;
    return HOST + (u.charAt(0) == "/" ? "" : "/") + u;
}

function topicId(url) {
    var m = /(?:mobile|topic)\/(\d+)/.exec("" + url);
    if (m) return m[1];
    m = /topic_id=(\d+)/.exec("" + url);
    if (m) return m[1];
    m = /^\s*(\d+)\s*$/.exec("" + url);
    return m ? m[1] : null;
}

function topicUrl(id) { return HOST + "/mobile/" + id + "/list/"; }

function catText(c) {
    if (!c) return "";
    var out = [];
    for (var i = 0; i < c.length; i++) out.push(typeof c[i] == "string" ? c[i] : (c[i].title || c[i].name || ""));
    return out.join(", ");
}

function topicItem(t) {
    var id = t.id || t.topic_id || (t.action_type && t.action_type.target_id);
    if (!id) return null;
    var desc = [];
    var author = t.author_name || (t.user && t.user.nickname) || "";
    if (author) desc.push(author);
    var cat = catText(t.category);
    if (cat) desc.push(cat);
    if (t.latest_comic_title) desc.push(t.latest_comic_title);
    else if (t.comics_count) desc.push(t.comics_count + " chương");
    if (!desc.length && t.description) desc.push(("" + t.description).substring(0, 80));
    return {
        name: t.title,
        link: topicUrl(id),
        cover: abs(t.vertical_image_url || t.image_url || t.cover_image_url || t.image || ""),
        description: desc.join(" · "),
        host: HOST
    };
}

function topicList(arr) {
    var data = [];
    var seen = {};
    for (var i = 0; arr && i < arr.length; i++) {
        var it = topicItem(arr[i]);
        if (it && !seen[it.link]) { seen[it.link] = 1; data.push(it); }
    }
    return data;
}

// tag id -> name, taken from /tag/0 (2026-11-12)
var TAGS = [
    [0, "全部"], [20, "恋爱"], [46, "古风"], [77, "大女主"], [80, "穿越"], [74, "校园"], [63, "玄幻"],
    [52, "总裁"], [65, "悬疑"], [92, "非人类"], [81, "恐怖"], [68, "异能"], [22, "奇幻"], [86, "系统"],
    [89, "重生"], [91, "末世"], [48, "都市"], [67, "热血"], [23, "剧情"], [62, "萌系"], [71, "搞笑"],
    [85, "武侠"], [54, "正能量"]
];

function tagIdByName(name) {
    for (var i = 0; i < TAGS.length; i++) if (TAGS[i][1] == name) return TAGS[i][0];
    return null;
}
