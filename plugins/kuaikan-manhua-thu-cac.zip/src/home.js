function execute() {
    return Response.success([
        {title: "人气榜", input: "rank:9", script: "gen.js"},
        {title: "飙升榜", input: "rank:7", script: "gen.js"},
        {title: "新作榜", input: "rank:2", script: "gen.js"},
        {title: "畅销榜", input: "rank:4", script: "gen.js"},
        {title: "免费榜", input: "rank:28", script: "gen.js"},
        {title: "完结榜", input: "rank:12", script: "gen.js"},
        {title: "韩漫榜", input: "rank:11", script: "gen.js"},
        {title: "日漫榜", input: "rank:10", script: "gen.js"},
        {title: "推荐 (全部)", input: "tag:0", script: "gen.js"}
    ]);
}
