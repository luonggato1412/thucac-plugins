load("common.js");

function execute(url) {
    var id = topicId(url);
    if (!id) return Response.error("Không nhận ra mã truyện trong link");
    var json = getJson(HOST + "/mini/v1/comic/mkuaikan/topic/detail?topic_id=" + id + "&page_source=7");
    var list = json && json.data && json.data.comic_list;
    if (!list) return Response.error("Không tải được danh sách chương");
    var data = [];
    for (var i = 0; i < list.length; i++) {
        var c = list[i];
        var readable = c.can_view !== false && !c.locked && (c.is_free !== false || c.can_view === true);
        var name = c.title || ("第" + (i + 1) + "话");
        if (!readable) name += c.vip_exclusive ? " [VIP]" : " [Trả phí]";
        data.push({name: name, url: HOST + "/mobile/comics/" + c.id + "/", pay: !readable, host: HOST});
    }
    // Keep oldest first.
    if (list.length > 1 && list[0].created_at && list[list.length - 1].created_at && list[0].created_at > list[list.length - 1].created_at) data.reverse();
    return Response.success(data);
}
