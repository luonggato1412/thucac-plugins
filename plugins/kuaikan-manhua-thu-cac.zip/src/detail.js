load("common.js");

function execute(url) {
    var id = topicId(url);
    if (!id) return Response.error("Không nhận ra mã truyện trong link");
    var json = getJson(HOST + "/mini/v1/comic/mkuaikan/topic/detail?topic_id=" + id + "&page_source=7");
    var t = json && json.data && json.data.topic_info;
    if (!t) return Response.error("Không tải được thông tin truyện");
    var list = json.data.comic_list || [];
    var free = 0;
    for (var i = 0; i < list.length; i++) if (list[i].can_view !== false && list[i].is_free !== false && !list[i].locked) free++;

    // user.nickname already joins all authors ("A（原著）+B"); related_author repeats them.
    var authors = [];
    var main = t.user && t.user.nickname ? ("" + t.user.nickname).trim() : "";
    if (main) authors.push(main);
    else {
        var ra = t.related_author || [];
        for (var k = 0; k < ra.length; k++) {
            var n = ra[k].nickname ? ("" + ra[k].nickname).trim() : "";
            if (n && authors.indexOf(n) < 0) authors.push(n);
        }
    }

    var status = "" + (t.update_status || "");
    var ongoing = !(status == "已完结" || status == "2" || t.update_status === 2);

    var genres = [];
    var cats = t.category || [];
    for (var g = 0; g < cats.length; g++) {
        var name = typeof cats[g] == "string" ? cats[g] : (cats[g].title || cats[g].name);
        var tid = tagIdByName(name);
        if (name && tid !== null) genres.push({title: name, input: "tag:" + tid, script: "gen.js"});
    }

    var info = [];
    if (authors.length) info.push("Tác giả: " + authors.join(", "));
    info.push("Trạng thái: " + (status || (ongoing ? "连载中" : "已完结")) + (t.update_day ? " (" + t.update_day + ")" : ""));
    info.push("Số chương: " + (list.length || t.comic_count || "?") + " · Đọc miễn phí: " + free);
    if (t.is_pay_comic || free < list.length) info.push("Chương trả phí / VIP được đánh dấu khóa và không đọc được.");

    return Response.success({
        name: t.title,
        cover: abs(t.vertical_image_url || t.cover_image_url || ""),
        author: authors.join(", "),
        description: t.description || "",
        detail: info.join("<br>"),
        ongoing: ongoing,
        genres: genres,
        url: topicUrl(id),
        host: HOST
    });
}
