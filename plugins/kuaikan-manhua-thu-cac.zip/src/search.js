load("common.js");

function execute(key, page) {
    key = ("" + key).trim();
    var json = getJson(HOST + "/search/web/complex?q=" + encodeURIComponent(key) + "&f=4");
    var hits = (json && json.data && json.data.topics && json.data.topics.hit) || [];
    var low = key.toLowerCase();
    // The API pads results with unrelated recommendations; keep only real matches.
    var matched = [];
    for (var i = 0; i < hits.length; i++) {
        var h = hits[i];
        var hay = ((h.title || "") + " " + ((h.user && h.user.nickname) || "") + " " + (h.author_name || "")).toLowerCase();
        if (hay.indexOf(low) >= 0) matched.push(h);
    }
    var data = topicList(matched);
    if (!data.length) {
        // Fallback: title suggestions (no cover).
        var sg = getJson(HOST + "/search/mini/suggest?q=" + encodeURIComponent(key) + "&size=20");
        var sh = (sg && (sg.hits || (sg.data && sg.data.hits))) || [];
        for (var j = 0; j < sh.length; j++) {
            if (sh[j].topic_id) data.push({name: sh[j].title, link: topicUrl(sh[j].topic_id), cover: "", description: "", host: HOST});
        }
    }
    if (!data.length && hits.length) data = topicList(hits.slice(0, 10));
    return Response.success(data);
}
