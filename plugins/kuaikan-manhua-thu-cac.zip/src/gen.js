load("common.js");

// input: "rank:{rankId}" (offset paging via since) or "tag:{tagId}[:{update_status}[:{region}]]"
function execute(input, page) {
    input = "" + input;
    if (input.indexOf("rank:") == 0) return rank(input.substring(5), page);
    if (input.indexOf("tag:") == 0) return tag(input.substring(4).split(":"), page);
    return Response.error("Đầu vào không hợp lệ: " + input);
}

function rank(id, page) {
    var since = parseInt(page || "0") || 0;
    var json = getJson(HOST + "/mini/v1/comic/mkuaikan/rank_list?since=" + since + "&limit=20&need_ranks=false&rank_id=" + id);
    if (!json || !json.data) return Response.error("Không tải được bảng xếp hạng");
    var topics = json.data.topics || [];
    var data = topicList(topics);
    var next = json.data.since;
    if (!topics.length || next === undefined || next === null || ("" + next) == ("" + since) || next == -1) next = null;
    return Response.success(data, next === null ? null : "" + next);
}

function tag(parts, page) {
    var p = parseInt(page || "1") || 1;
    var url = HOST + "/search/mini/topic/multi_filter?page=" + p + "&size=20&tag_id=" + (parts[0] || 0) +
        "&update_status=" + (parts[1] || 0) + "&pay_status=0&sort=1&gender=0";
    if (parts[2]) url += "&label_dimension_origin=" + parts[2];
    var json = getJson(url);
    if (!json || !json.hits) return Response.error("Không tải được danh sách truyện");
    var arr = json.hits.topicMessageList || [];
    var data = topicList(arr);
    var total = json.total || 0;
    var more = arr.length > 0 && p * 20 < total;
    return Response.success(data, more ? "" + (p + 1) : null);
}
