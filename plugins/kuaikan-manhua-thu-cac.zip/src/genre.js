load("common.js");

function execute() {
    var data = [];
    for (var i = 0; i < TAGS.length; i++) {
        data.push({title: TAGS[i][1], input: "tag:" + TAGS[i][0], script: "gen.js"});
    }
    data.push({title: "已完结 (全部)", input: "tag:0:2", script: "gen.js"});
    data.push({title: "国漫", input: "tag:0:0:2", script: "gen.js"});
    data.push({title: "韩漫", input: "tag:0:0:3", script: "gen.js"});
    data.push({title: "日漫", input: "tag:0:0:4", script: "gen.js"});
    return Response.success(data);
}
