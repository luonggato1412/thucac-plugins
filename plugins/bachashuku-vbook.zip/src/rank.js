load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    let doc = fetchDoc(url.replace("{page}", page));
    if (!doc) return null;

    let data = parseRows(doc);
    if (data.length === 0) {
        // Fallback: compact ranking list <ul class="ulnum"><li><a class="db cf" ...><em/><b/>Title</a>
        doc.select("ul.ulnum li a.db").forEach(a => {
            let link = a.attr("href");
            a.select("em, b, i").remove();
            let id = (link.match(/\/book\/(\d+)/) || [])[1];
            data.push({
                name: a.text(),
                link: link,
                cover: id ? "https://image.8xsk.org/" + Math.floor(id / 1000) + "/" + id + "/" + id + "s.jpg" : "",
                host: BASE_URL
            });
        });
    }
    return Response.success(data, nextPage(doc));
}
