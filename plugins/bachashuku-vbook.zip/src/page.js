load("config.js");

// Chapter list is split into pages: /book/{id}_{page}.html (20 chapters each)
function execute(url) {
    let bookId = url.match(/\/(?:book|read)\/(\d+)/)[1];
    let first = BASE_URL + "/book/" + bookId + "_1.html";
    let doc = fetchDoc(first);
    if (!doc) return null;

    let total = 1;
    let m = doc.select("#pagestats").text().match(/\/\s*(\d+)/);
    if (m) total = parseInt(m[1]);

    let pages = [];
    for (let p = 1; p <= total; p++) {
        pages.push(BASE_URL + "/book/" + bookId + "_" + p + ".html");
    }
    return Response.success(pages);
}
