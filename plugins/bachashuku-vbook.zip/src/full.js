load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    let doc = fetchDoc(url.replace("{page}", page));
    if (!doc) return null;

    let data = [];
    doc.select("tbody#jieqi_page_contents tr").forEach(tr => {
        let tds = tr.select("td");
        if (tds.size() < 2) return;
        let a = tds.get(1).select("a.db").first();
        if (!a) return;
        let author = a.select("span").text().replace("/", "").trim();
        a.select("span").remove();
        let link = a.attr("href");
        let id = (link.match(/\/book\/(\d+)/) || [])[1];
        data.push({
            name: a.text(),
            link: link,
            cover: id ? "https://image.8xsk.org/" + Math.floor(id / 1000) + "/" + id + "/" + id + "s.jpg" : "",
            description: tds.get(0).text() + " | " + author + (tds.size() > 3 ? " | " + tds.get(tds.size() - 1).text() : ""),
            host: BASE_URL
        });
    });
    return Response.success(data, nextPage(doc));
}
