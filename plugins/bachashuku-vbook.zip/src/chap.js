load("config.js");

// Chapter pages are protected by a Cloudflare challenge, so a plain fetch
// usually gets 403. Try fetch first, then fall back to the in-app browser.
function execute(url) {
    url = normalizeUrl(url);
    let doc = fetchDoc(url);
    if (!doc || !hasContent(doc)) {
        doc = loadWithBrowser(url);
    }
    if (!doc) return Response.error("Không tải được chương. Hãy mở trang trong trình duyệt của vBook để qua Cloudflare rồi thử lại.");

    let content = getContent(doc);
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    return Response.success(clean(content));
}

function loadWithBrowser(url) {
    let browser = Engine.newBrowser();
    try {
        let doc = browser.launch(url, 30000);
        // Age gate: press "是，我已成年"
        if (doc && doc.select("button[name=action][value=yes]").size() > 0) {
            browser.callJs("document.querySelector('button[name=action][value=yes]').click();", 5000);
            sleep(2000);
            doc = browser.launch(url, 30000);
        }
        // Wait for Cloudflare challenge to finish
        for (let i = 0; i < 5 && doc && !hasContent(doc); i++) {
            sleep(3000);
            doc = browser.html();
        }
        return doc;
    } catch (e) {
        return null;
    } finally {
        browser.close();
    }
}

// Only checks, never changes the page: the old version removed every <div>
// while checking, so the second pass found too little text and reported
// "Không tìm thấy nội dung chương" even on a page that had loaded fine.
function hasContent(doc) {
    return findContentEl(doc) !== null;
}

function findContentEl(doc) {
    if (!doc) return null;
    let selectors = ["#content", ".read-content", "#acontent", "#chaptercontent", ".content", "article"];
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]).first();
        if (el && el.text().length > 50) return el;
    }
    return null;
}

function getContent(doc) {
    let el = findContentEl(doc);
    if (!el) return null;
    el.select("script, style, iframe, ins").remove();
    let full = el.html();
    // Drop ad cards and links, but keep them if the chapter text itself sits inside <div>s.
    el.select("a, div").remove();
    if (el.text().length > 50) return el.html();
    return full;
}

function clean(htm) {
    return htm
        .replace(/(H漫|hgame)\s*[：:][⊙\s]*(<br\s*\/?>)?/gi, "")
        .replace(/本站发布页\s*[:：]\s*[^<\s]*/g, "")
        .replace(/[​-‍﻿]/g, "")
        .replace(/&nbsp;/g, "")
        .replace(/(<br\s*\/?>\s*){2,}/gi, "<br>")
        .replace(/^(\s*<br\s*\/?>)+|(<br\s*\/?>\s*)+$/gi, "")
        .trim();
}
