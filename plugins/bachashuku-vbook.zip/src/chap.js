load("config.js");

// Chapter pages are protected by a Cloudflare challenge, so a plain fetch
// usually gets 403. Try fetch first, then fall back to the in-app browser.
function execute(url) {
    url = normalizeUrl(url);
    let doc = fetchDoc(url);
    if (!doc || !hasContent(doc)) {
        doc = loadWithBrowser(url);
    }
    if (!doc) return Response.error("Không tải được chương. Hãy mở trang trong trình duyệt của vBook để qua Cloudflare rồi thử lại.");

    let content = getContent(doc);
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    return Response.success(clean(content));
}

function loadWithBrowser(url) {
    let browser = Engine.newBrowser();
    try {
        let doc = browser.launch(url, 30000);
        // Age gate: press "是，我已成年"
        if (doc && doc.select("button[name=action][value=yes]").size() > 0) {
            browser.callJs("document.querySelector('button[name=action][value=yes]').click();", 5000);
            sleep(2000);
            doc = browser.launch(url, 30000);
        }
        // Wait for Cloudflare challenge to finish
        for (let i = 0; i < 5 && doc && !hasContent(doc); i++) {
            sleep(3000);
            doc = browser.html();
        }
        return doc;
    } catch (e) {
        return null;
    } finally {
        browser.close();
    }
}

function hasContent(doc) {
    return getContent(doc) !== null;
}

function getContent(doc) {
    let selectors = ["#content", ".read-content", "#acontent"];
    for (let i = 0; i < selectors.length; i++) {
        let el = doc.select(selectors[i]).first();
        if (el && el.text().length > 50) {
            el.select("script, a, style, iframe, ins, div").remove();
            return el.html();
        }
    }
    return null;
}

function clean(htm) {
    return htm
        .replace(/(H漫|hgame)\s*[：:][⊙\s]*(<br\s*\/?>)?/gi, "")
        .replace(/本站发布页\s*[:：]\s*[^<\s]*/g, "")
        .replace(/[​-‍﻿]/g, "")
        .replace(/&nbsp;/g, "")
        .replace(/(<br\s*\/?>\s*){2,}/gi, "<br>")
        .replace(/^(\s*<br\s*\/?>)+|(<br\s*\/?>\s*)+$/gi, "")
        .trim();
}
