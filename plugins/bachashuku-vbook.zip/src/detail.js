load("config.js");

function execute(url) {
    let bookId = url.match(/\/(?:book|read)\/(\d+)/)[1];
    url = BASE_URL + "/book/" + bookId + ".html";
    let doc = fetchDoc(url);
    if (!doc) return null;

    let h4 = doc.select(".row_textl h4").first();
    h4.select("span").remove();

    let intro = doc.select("#introa").first() || doc.select("#introl").first();
    if (intro) intro.select("a").remove();

    let infoEl = doc.select(".row_textl p.gray").first();
    if (infoEl) infoEl.select("span.fr").remove();
    let tags = [];
    doc.select("a[href*=tagarticle]").forEach(t => tags.push(t.text().trim()));
    let latest = doc.select(".c_row.nw a[href*=/read/]").first();

    let detail = infoEl ? infoEl.html().replace(/<span class="iconfont">[^<]*<\/span>/g, "") : "";
    if (latest) detail += "<br>最新：" + latest.text();

    return Response.success({
        name: h4.text().replace(/[《》]/g, "").trim(),
        cover: fixCover(doc.select("img.cover_l").attr("src")),
        author: doc.select(".row_textl a[href*=authorarticle]").text(),
        description: intro ? intro.html() : "",
        detail: detail,
        genres: tags.map(t => ({ title: t })),
        host: BASE_URL,
        url: url
    });
}
