load("config.js");

function execute(key, page) {
    let doc;
    if (page && page !== "1") {
        doc = fetchDoc(BASE_URL + "/modules/article/search.php?searchkey=" + encodeURIComponent(key) + "&searchtype=all&page=" + page);
    } else {
        doc = fetchDoc(BASE_URL + "/modules/article/search.php", {
            method: "POST",
            body: "searchkey=" + encodeURIComponent(key) + "&searchtype=all",
            headers: { "Content-Type": "application/x-www-form-urlencoded" }
        });
    }
    if (!doc) return null;

    // A single exact match may land directly on the book page
    if (doc.select(".row_textl h4").size() > 0) {
        let h4 = doc.select(".row_textl h4").first();
        h4.select("span").remove();
        let link = doc.select("link[rel=canonical]").attr("href")
            || doc.select("meta[property=og:url]").attr("content");
        return Response.success([{
            name: h4.text().replace(/[《》]/g, ""),
            link: link,
            cover: fixCover(doc.select("img.cover_l").attr("src")),
            host: BASE_URL
        }]);
    }

    let data = parseRows(doc, true);
    if (data.length === 0) {
        doc.select("#jieqi_page_contents tr").forEach(tr => {
            let a = tr.select("a[href*=/book/]").first();
            if (!a) return;
            a.select("span").remove();
            data.push({ name: a.text(), link: a.attr("href"), host: BASE_URL });
        });
    }
    return Response.success(data, nextPage(doc));
}
