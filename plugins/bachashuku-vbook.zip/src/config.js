let BASE_URL = "https://bachashuku.org";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}

// Cookie set by /age_verify.php after pressing "是，我已成年"
let AGE_COOKIE = "age18_ok=1";

function normalizeUrl(url) {
    url = url.replace(/^(https?:\/\/)?(www\.)?(bachashuku|8xsk)\.org/, BASE_URL);
    if (url.startsWith("/")) url = BASE_URL + url;
    return url.replace("#gsc.tab=0", "");
}

function fetchDoc(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    // Chapter pages (/read/) sit behind Cloudflare: never override Cookie there,
    // so the cf_clearance + age18_ok cookies saved by vBook's browser are used.
    if (!/\/read\//.test(url)) {
        options.headers["Cookie"] = AGE_COOKIE;
    }
    let response = fetch(normalizeUrl(url), options);
    if (response.ok) return response.html();
    return null;
}

function fixCover(src) {
    if (!src) return "";
    if (src.startsWith("//")) return "https:" + src;
    if (src.startsWith("/")) return BASE_URL + src;
    return src;
}

// Parse a Jieqi list (.c_row items) used by category / search / rank pages
function parseRows(doc, authorFirst) {
    let data = [];
    doc.select("#jieqi_page_contents .c_row").forEach(e => {
        let a = e.select("a.db").first();
        if (!a) return;
        let info = e.select("p.gray").first();
        let author = "";
        let desc = "";
        if (info) {
            let parts = info.html().split(/<br\s*\/?>/i);
            author = Html.parse(parts[0]).text();
            if (author.indexOf("|") !== -1) author = author.split("|")[authorFirst ? 0 : 1];
            author = author.trim();
            desc = parts.length > 1 ? Html.parse(parts.slice(1).join(" ")).text().trim() : "";
        }
        data.push({
            name: e.select("h4").text(),
            link: a.attr("href"),
            cover: fixCover(e.select("img").attr("src")),
            description: author ? author + " - " + desc : desc,
            host: BASE_URL
        });
    });
    return data;
}

function nextPage(doc) {
    let next = doc.select("#pagelink a.next").first();
    if (!next) return null;
    let href = next.attr("href");
    if (!href || href === "#") return null;
    let m = href.match(/\/(\d+)\.html/) || href.match(/page=(\d+)/);
    return m ? m[1] : null;
}
