load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    let doc = fetchDoc(url.replace("{page}", page));
    if (!doc) return null;
    return Response.success(parseRows(doc), nextPage(doc));
}
