load("config.js");

function execute(url) {
    if (!/\/book\/\d+_\d+\.html/.test(url)) {
        let bookId = url.match(/\/(?:book|read)\/(\d+)/)[1];
        url = BASE_URL + "/book/" + bookId + "_1.html";
    }
    let doc = fetchDoc(url);
    if (!doc) return null;

    let data = [];
    doc.select("dl.index dd a.db").forEach(e => {
        data.push({
            name: e.text().replace(/\s*\(\d\d-\d\d\)$/, ""),
            url: e.attr("href"),
            host: BASE_URL
        });
    });
    return Response.success(data);
}
