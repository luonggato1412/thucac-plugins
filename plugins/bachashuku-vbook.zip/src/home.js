function execute() {
    return Response.success([
        { title: "周点击榜", input: "/top/weekvisit/{page}.html", script: "full.js" },
        { title: "月点击榜", input: "/top/monthvisit/{page}.html", script: "full.js" },
        { title: "总点击榜", input: "/top/allvisit/{page}.html", script: "full.js" },
        { title: "总推荐榜", input: "/top/allvote/{page}.html", script: "full.js" },
        { title: "最新入库", input: "/top/postdate/{page}.html", script: "full.js" },
        { title: "最近更新", input: "/modules/article/articlefilter.php?order=lastupdate&page={page}", script: "gen.js" },
        { title: "全本小说", input: "/modules/article/toplist.php?order=allvisit&fullflag=1&page={page}", script: "full.js" }
    ]);
}
