load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    const doc = fetch(BASE_URL + url).html();
    const el = doc.select(".pure-g > div");
    const data = [];
    for (var i = 0; i < el.size(); i++) {
        var e = el.get(i);
        var h3 = e.select("h3").last();
        var a = e.select("a").first();
        if (h3 == null || a == null) continue;
        var img = e.select("amp-img, img").first();
        var small = e.select(".text-truncate small").first();
        data.push({
            name: h3.text(),
            link: a.attr("href"),
            cover: img ? (img.attr("src") || img.attr("data-src")) : "",
            description: small ? small.text() : "",
            host: BASE_URL
        });
    }
    return Response.success(data);
}
