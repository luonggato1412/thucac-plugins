load("config.js");

// pageData.chapterInfo.content holds the chapter as <p> paragraphs.
// VIP chapters that aren't bought only carry a ~100 character preview.
function execute(url) {
    url = normalizeUrl(url);
    let data = fetchPageData(url);
    if (!data || !data.chapterInfo) return Response.error("Không tải được chương");
    let c = data.chapterInfo;

    let content = String(c.content || "");
    let locked = c.vipStatus == 1 && c.isBuy != 1 && c.chapterType != 2;
    if (locked) {
        return Response.success("<p>[Chương VIP] Chương này phải mua trên Qidian (" + (c.price || "?") +
            " điểm). Plugin chỉ đọc được chương miễn phí.</p>");
    }
    if (c.fEnS || c.cES || c.randomFont) {
        // Encrypted or font-obfuscated text: show it but warn
        content = "<p>[Cảnh báo] Chương này bị mã hoá phông chữ, nội dung có thể sai.</p>" + content;
    }

    content = content
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<(\/?)p[^>]*>/gi, "<$1p>")
        .replace(/[​-‍﻿]/g, "")
        .replace(/<p>[\s　]*/g, "<p>")
        .replace(/<p><\/p>/g, "")
        .trim();
    if (!content) return Response.error("Không tìm thấy nội dung chương");

    let say = c.authorWords && c.authorWords.content;
    if (say) content += "<p>——</p><p>作者的话：" + String(say).replace(/\r?\n/g, "</p><p>") + "</p>";
    return Response.success(content);
}
