load("config.js");

function execute(url) {
    let bid = bookId(url);
    if (!bid) return Response.error("Link truyện không hợp lệ");
    url = bookUrl(bid);
    let html = fetchText(url);
    let data = parsePageData(html);
    if (!data || !data.bookInfo) return Response.error("Không tải được trang truyện");
    let b = data.bookInfo;

    let cover = "";
    let ld = html.match(/<script[^>]*application\/ld\+json[^>]*>([\s\S]*?)<\/script>/);
    if (ld) {
        try {
            let j = JSON.parse(ld[1]);
            let img = j.image || (j["@graph"] && j["@graph"][0] && j["@graph"][0].image);
            if (img) cover = String(Array.isArray(img) ? img[0] : (img.url || img));
        } catch (e) {
        }
    }
    cover = fixCover(cover, bid);

    let status = b.actionStatus || "";
    let genre = [b.chanName, b.subCateName].filter(x => x).join("·");
    let words = b.wordsCnt ? (b.wordsCnt >= 10000 ? (b.wordsCnt / 10000).toFixed(2) + "万字" : b.wordsCnt + "字") : "";

    let detail = [];
    if (b.authorName) detail.push("作者：" + b.authorName);
    if (genre) detail.push("类别：" + genre);
    if (status) detail.push("状态：" + status);
    if (words) detail.push("字数：" + words);
    if (data.cTCnt) detail.push("章节：" + data.cTCnt);
    if (b.updTime) detail.push("更新：" + b.updTime);
    if (b.updChapterName) detail.push("最新：" + b.updChapterName);

    let genres = [];
    if (b.chanId && b.chanName) genres.push({ title: b.chanName, input: "/category/catid" + b.chanId + "/", script: "gen.js" });

    return Response.success({
        name: b.bookName,
        cover: cover,
        author: b.authorName || "",
        description: String(b.desc || "").replace(/\r?\n/g, "<br>"),
        detail: detail.join("<br>"),
        ongoing: status.indexOf("完") === -1,
        genres: genres,
        host: BASE_URL,
        url: url
    });
}
