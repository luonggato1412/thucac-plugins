load("config.js");

// pageData.vs = volumes {vN, vS (1 = VIP), cs: [{id, cN, sS, uuid}]}
function execute(url) {
    let bid = bookId(url);
    if (!bid) return Response.error("Link truyện không hợp lệ");
    let data = fetchPageData(catalogUrl(bid));
    if (!data || !data.vs) return Response.error("Không tải được mục lục");

    let out = [];
    data.vs.forEach(v => {
        let vip = v.vS == 1;
        (v.cs || []).forEach(c => {
            if (!c || !c.id) return;
            out.push({
                name: (vip ? "[VIP] " : "") + c.cN,
                url: chapterUrl(bid, c.id),
                pay: vip,
                host: BASE_URL
            });
        });
    });
    return Response.success(out);
}
