let BASE_URL = "https://m.qidian.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL.replace(/\/+$/, "");
    }
} catch (error) {
}

let UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

function normalizeUrl(url) {
    url = String(url);
    if (url.startsWith("//")) url = "https:" + url;
    url = url.replace(/^(https?:\/\/)?(m|www|book)\.qidian\.com/, BASE_URL);
    if (url.startsWith("/")) url = BASE_URL + url;
    return url;
}

function fetchText(url) {
    let response = fetch(normalizeUrl(url), {
        headers: { "User-Agent": UA, "Referer": BASE_URL + "/" }
    });
    if (response.ok) return response.text();
    return null;
}

// Every page is server-rendered with its data in
// <script id="vite-plugin-ssr_pageContext" type="application/json">…</script>
function parsePageData(html) {
    if (!html) return null;
    html = String(html);
    let i = html.indexOf('id="vite-plugin-ssr_pageContext"');
    if (i < 0) i = html.indexOf("id='vite-plugin-ssr_pageContext'");
    if (i < 0) return null;
    let start = html.indexOf(">", i) + 1;
    let end = html.indexOf("</script>", start);
    if (start <= 0 || end < 0) return null;
    let obj;
    try {
        obj = JSON.parse(html.substring(start, end));
    } catch (e) {
        return null;
    }
    let ctx = obj.pageContext || obj;
    let props = ctx.pageProps || {};
    return props.pageData || null;
}

function fetchPageData(url) {
    return parsePageData(fetchText(url));
}

function bookId(url) {
    let m = String(url).match(/\/(?:book|info|chapter)\/(\d+)/);
    if (m) return m[1];
    m = String(url).match(/(?:bookId|bid)=(\d+)/);
    return m ? m[1] : null;
}

function bookUrl(bid) {
    return BASE_URL + "/book/" + bid + "/";
}

function catalogUrl(bid) {
    return BASE_URL + "/book/" + bid + "/catalog/";
}

function chapterUrl(bid, cid) {
    return BASE_URL + "/chapter/" + bid + "/" + cid + "/";
}

function coverUrl(bid) {
    return "https://bookcover.yuewen.com/qdbimg/349573/" + bid + "/180";
}

function fixCover(img, bid) {
    if (!img) return coverUrl(bid);
    img = String(img);
    if (img.startsWith("//")) img = "https:" + img;
    return img;
}

function stripTags(s) {
    return String(s || "").replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
}

// Book item shape shared by search, rank and category lists:
// {bid, bName, bAuth, cat, subCateName|subCat, state, cnt, desc, imgUrl}
function toBook(r) {
    if (!r || !r.bid) return null;
    let parts = [];
    if (r.bAuth) parts.push(stripTags(r.bAuth));
    let cat = r.cat || r.catName || "";
    let sub = r.subCateName || r.subCat || "";
    if (cat || sub) parts.push([cat, sub].filter(x => x).join("·"));
    if (r.state) parts.push(r.state);
    if (r.cnt) parts.push(r.cnt);
    return {
        name: stripTags(r.bName),
        link: bookUrl(r.bid),
        cover: fixCover(r.imgUrl, r.bid),
        description: parts.join(" | "),
        host: BASE_URL
    };
}

function toBooks(records) {
    let data = [];
    (records || []).forEach(r => {
        let b = toBook(r);
        if (b) data.push(b);
    });
    return data;
}

// Paged list object: {total, pageNum, pageSize, isLast, records}
function nextPage(list, page) {
    if (!list || list.isLast) return null;
    if (!list.records || list.records.length === 0) return null;
    let cur = parseInt(list.pageNum || page || 1);
    if (list.pageMax && cur >= list.pageMax) return null;
    return String(cur + 1);
}

function withPage(url, page) {
    url = normalizeUrl(url);
    if (url.indexOf("{page}") >= 0) return url.replace("{page}", page);
    if (String(page) === "1") return url;
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + "pageNum=" + page;
}

// The list APIs need the _csrfToken cookie, which every HTML page sets.
// Returns {token, data} where data is the page's pageData.
function fetchWithToken(url) {
    let response = fetch(normalizeUrl(url), {
        headers: { "User-Agent": UA, "Referer": BASE_URL + "/" }
    });
    if (!response.ok) return null;
    let token = "";
    try {
        let headers = response.headers || {};
        for (let k in headers) {
            if (String(k).toLowerCase() !== "set-cookie") continue;
            let m = String(headers[k]).match(/_csrfToken=([^;,\s]+)/);
            if (m) token = m[1];
        }
    } catch (e) {
    }
    let html = response.text();
    if (!token) {
        let m = String(html).match(/_csrfToken["'=:\s]+([0-9a-zA-Z-]{20,})/);
        if (m) token = m[1];
    }
    return { token: token, data: parsePageData(html) };
}

function fetchApi(url, token, referer) {
    let headers = { "User-Agent": UA, "Referer": referer, "Accept": "application/json" };
    if (token) headers["Cookie"] = "_csrfToken=" + token;
    let response = fetch(url + (url.indexOf("?") >= 0 ? "&" : "?") + "_csrfToken=" + encodeURIComponent(token), {
        headers: headers
    });
    if (!response.ok) return null;
    try {
        let j = JSON.parse(response.text());
        return j && j.code == 0 ? j.data : null;
    } catch (e) {
        return null;
    }
}
