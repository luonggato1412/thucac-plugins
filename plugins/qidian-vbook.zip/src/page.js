load("config.js");

// The whole catalog is server-rendered on one page: /book/{id}/catalog/
function execute(url) {
    let bid = bookId(url);
    if (!bid) return Response.error("Link truyện không hợp lệ");
    return Response.success([catalogUrl(bid)]);
}
