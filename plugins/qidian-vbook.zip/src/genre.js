load("config.js");

// Categories come from m.qidian.com/category/ (info[]: {catId, catName});
// fall back to a fixed list if the page can't be read.
function execute() {
    let cats = [];
    let data = fetchPageData("/category/");
    if (data && data.info) {
        data.info.forEach(c => {
            if (c && c.catId !== undefined && c.catName) cats.push([String(c.catId), c.catName]);
        });
    }
    if (cats.length === 0) {
        cats = [
            ["21", "玄幻"], ["1", "奇幻"], ["2", "武侠"], ["22", "仙侠"], ["4", "都市"], ["15", "现实"],
            ["6", "军事"], ["5", "历史"], ["7", "游戏"], ["8", "体育"], ["9", "科幻"], ["20109", "诸天无限"],
            ["10", "悬疑"], ["12", "轻小说"], ["20076", "短篇"]
        ];
    }
    return Response.success(cats.map(c => ({
        title: c[1],
        input: "/category/catid" + c[0] + "/",
        script: "gen.js"
    })));
}
