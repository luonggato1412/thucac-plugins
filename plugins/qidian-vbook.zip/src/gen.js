load("config.js");

// Page 1 comes from the server-rendered page (/rank/{key}/ or /category/catid{N}/).
// Later pages only exist through the infinite-scroll APIs, which need the _csrfToken cookie:
//   /webcommon/rank/{key}list?catId=-1&pageNum=N
//   /webcommon/category/list?catId=N&pageNum=N
function execute(url, page) {
    if (!page) page = "1";
    url = normalizeUrl(url);
    let res = fetchWithToken(url);
    if (!res || !res.data) return Response.error("Không tải được danh sách");
    let first = res.data.records ? res.data : (res.data.list || res.data);
    if (String(page) === "1") return Response.success(toBooks(first.records), nextPage(first, page));

    let api = null;
    let m = url.match(/\/rank\/([a-zA-Z]+)\//);
    if (m) {
        let key = m[1] === "readindex" ? "readIndex" : m[1];
        api = BASE_URL + "/webcommon/rank/" + key + "list?catId=-1&pageNum=" + page;
    }
    m = url.match(/\/category\/catid(-?\d+)/);
    if (m) api = BASE_URL + "/webcommon/category/list?catId=" + m[1] + "&pageNum=" + page;
    if (!api) return Response.success([], null);

    let list = fetchApi(api, res.token, url);
    if (!list) {
        // Older endpoint that also answered during testing
        if (url.indexOf("/rank/") >= 0) list = fetchApi(api.replace("/webcommon/rank/", "/majax/rank/"), res.token, url);
    }
    if (!list) return Response.error("Không tải được trang " + page);
    if (!list.pageNum) list.pageNum = page;
    if (!list.pageMax && first.pageMax) list.pageMax = first.pageMax;
    return Response.success(toBooks(list.records), nextPage(list, page));
}
