// Ranking lists on m.qidian.com/rank/{key}/ (rankDetail pages)
function execute() {
    let ranks = [
        ["hotsales", "畅销榜"], ["yuepiao", "月票榜"], ["readindex", "阅读指数榜"], ["rec", "推荐榜"],
        ["update", "更新榜"], ["sign", "签约作者新书榜"], ["newbook", "新书榜"], ["newauthor", "新人作者新书榜"],
        ["newfans", "新增粉丝榜"]
    ];
    return Response.success(ranks.map(r => ({
        title: r[1],
        input: "/rank/" + r[0] + "/",
        script: "gen.js"
    })));
}
