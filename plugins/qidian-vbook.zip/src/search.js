load("config.js");

function execute(key, page) {
    if (!page) page = "1";
    let url = BASE_URL + "/soushu/" + encodeURIComponent(key) + ".html";
    let data = fetchPageData(withPage(url, page));
    if (!data) return Response.error("Tìm kiếm thất bại");
    let list = data.bookInfo || {};
    return Response.success(toBooks(list.records), nextPage(list, page));
}
