function execute() {
    return Response.success([
        {title: "Mới nhất", input: "https://hentai2read.com/browse", script: "gen.js"},
        {title: "Trending", input: "https://hentai2read.com/browse/trending", script: "gen.js"},
        {title: "Xem nhiều", input: "https://hentai2read.com/browse/most-viewed", script: "gen.js"},
        {title: "Đánh giá cao", input: "https://hentai2read.com/browse/top-rated", script: "gen.js"},
        {title: "Hoàn thành", input: "https://hentai2read.com/browse/completed", script: "gen.js"}
    ]);
}
