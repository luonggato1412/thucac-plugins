var HOST = "https://hentai2read.com";

function pageData(url) {
    var res = Http.get(url);
    var doc = res.html();
    var s = doc.select("script[data-page]").first();
    if (s == null) return null;
    return JSON.parse(s.html());
}

function abs(u) {
    if (!u) return "";
    u = "" + u;
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u;
    return HOST + (u.charAt(0) == "/" ? "" : "/") + u;
}

function img(c) {
    if (!c) return "";
    if (typeof c == "string") return abs(c);
    return abs(c.url || c.src || c.jpg || c.original || c.default || "");
}

function bookList(books) {
    var data = [];
    var arr = (books && books.data) || [];
    for (var i = 0; i < arr.length; i++) {
        var b = arr[i];
        var desc = [];
        if (b.chapters) desc.push(b.chapters + " chương");
        if (b.pageCount) desc.push(b.pageCount + " trang");
        if (b.artist && b.artist.name) desc.push(b.artist.name);
        data.push({
            name: b.title,
            link: abs(b.url),
            cover: img(b.cover),
            description: desc.join(" · "),
            host: HOST
        });
    }
    return data;
}

function findBooks(props) {
    if (!props) return null;
    if (props.books) return props.books;
    for (var k in props) {
        var v = props[k];
        if (v && v.data && v.data.length !== undefined && (v.lastPage || v.last_page)) return v;
    }
    return null;
}

function nextPage(books, page) {
    var last = books ? (books.lastPage || books.last_page || 0) : 0;
    return page < last ? ("" + (page + 1)) : null;
}

function execute(key, page) {
    var p = parseInt(page || "1") || 1;
    var url = HOST + "/search?q=" + encodeURIComponent(key) + (p > 1 ? "&page=" + p : "");
    var json = pageData(url);
    if (!json) return Response.error("Không đọc được trang tìm kiếm");
    var books = findBooks(json.props);
    return Response.success(bookList(books), nextPage(books, p));
}
