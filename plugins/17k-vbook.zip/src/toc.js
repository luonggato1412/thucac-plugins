load("config.js");

// dl.Volume > dd > a; VIP chapters have <span class="ellipsis vip">.
// The "作品相关" volume only holds author notices, so it is skipped.
function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");
    let doc = fetchDoc(tocUrl(id));
    if (!doc) return Response.error("Không tải được mục lục");

    let data = [];
    let seen = {};
    let volumes = doc.select("dl.Volume");
    let skipNotice = volumes.size() > 1;
    volumes.forEach(dl => {
        let vol = cleanText(dl.select("dt span.tit").text());
        if (skipNotice && vol === "作品相关") return;
        dl.select("dd a[href*=/chapter/]").forEach(a => {
            let m = a.attr("href").match(/\/chapter\/(\d+)\/(\d+)\.html/);
            if (!m || seen[m[2]]) return;
            seen[m[2]] = true;
            let span = a.select("span.ellipsis").first();
            let vip = span ? span.hasClass("vip") : a.select(".vip").size() > 0;
            let name = cleanText(span ? span.text() : a.text());
            data.push({
                name: vip ? name + " [VIP]" : name,
                url: BASE_URL + "/chapter/" + m[1] + "/" + m[2] + ".html",
                pay: vip,
                host: BASE_URL
            });
        });
    });
    return Response.success(data);
}
