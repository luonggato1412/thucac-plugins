load("config.js");

// The whole chapter list sits on one page: /list/{id}.html
function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");
    return Response.success([tocUrl(id)]);
}
