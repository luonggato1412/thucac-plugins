load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    let doc = fetchDoc(url.replace("{page}", page));
    if (!doc) return Response.error("Không tải được danh sách");
    if (url.indexOf("/top/") >= 0) return Response.success(parseTop(doc), null);
    return Response.success(parseAll(doc), nextPageNum(doc, page));
}

// /all/book/...: div.alltable tr.bg0 / tr.bg1
function parseAll(doc) {
    let data = [];
    doc.select("div.alltable tr.bg0, div.alltable tr.bg1").forEach(tr => {
        let a = tr.select("td.td3 a[href*=/book/]").first();
        if (!a) return;
        let id = bookId(a.attr("href"));
        if (!id) return;
        let genre = cleanText(tr.select("td.td2").text()).replace(/[\[\]]/g, "");
        let author = cleanText(tr.select("td.td6").text());
        let latest = cleanText(tr.select("td.td4").text());
        let status = cleanText(tr.select("td.td8").text());
        let desc = [author, genre, latest].filter(x => x).join(" | ");
        if (status) desc += " (" + status + ")";
        data.push({
            name: cleanText(a.text()),
            link: bookUrl(id),
            cover: fixCover(tr.select("img").attr("src"), id),
            description: desc,
            host: BASE_URL
        });
    });
    return data;
}

// Ranking pages hold many tabs (div.TYPE); the first table is enough.
function parseTop(doc) {
    let data = [];
    let seen = {};
    let box = doc.select("div.TYPE").first() || doc;
    box.select("table tr").forEach(tr => {
        let tds = tr.select("td");
        if (tds.size() < 6) return;
        let a = tr.select("a[href*=/book/]:not([href*=/all/])").first();
        if (!a) return;
        let id = bookId(a.attr("href"));
        if (!id || seen[id]) return;
        seen[id] = true;
        let name = a.attr("title") || a.text();
        let genre = cleanText(tds.get(1).text()).replace(/[\[\]]/g, "");
        let author = tr.select("a[href*=user.17k.com]").attr("title") || cleanText(tds.get(5).text());
        let latest = tr.select("a[href*=/chapter/]").attr("title");
        let desc = [author, genre, latest].filter(x => x).join(" | ");
        data.push({
            name: cleanText(name),
            link: bookUrl(id),
            cover: coverUrl(id),
            description: desc,
            host: BASE_URL
        });
    });
    return data;
}
