load("config.js");

function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");
    url = bookUrl(id);
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không tải được trang truyện");

    let info = doc.select("div.BookInfo").first() || doc;
    let name = cleanText(info.select("h1").first() ? info.select("h1").first().text() : "");
    let title = doc.select("title").text().split("_");
    if (!name) name = cleanText(title[0]);
    let author = cleanText(doc.select("div.AuthorInfo a.name, .author-name, a[href*=user.17k.com/see]").first() ?
        doc.select("div.AuthorInfo a.name, .author-name, a[href*=user.17k.com/see]").first().text() : "");
    if (!author && title.length > 1) author = cleanText(title[1]);

    let cover = fixCover(doc.select("#bookCover img").attr("src"), id);

    let intro = doc.select("p.intro").first();
    let desc = intro ? intro.html().replace(/<\/?a[^>]*>/g, "").replace(/(\s*<br\s*\/?>\s*)+/gi, "<br>").trim() : "";

    let label = cleanText(info.select("div.label").text());
    let ongoing = label.indexOf("完本") === -1 && label.indexOf("完结") === -1;

    let genres = [];
    let genreName = "";
    doc.select("#bookInfo th").forEach(th => {
        if (th.text().indexOf("作品类别") >= 0) {
            let td = th.nextElementSibling();
            if (td) {
                genreName = cleanText(td.text());
                let a = td.select("a").first();
                if (a) genres.push({ title: genreName, input: a.attr("href").replace(/_1\.html$/, "_{page}.html"), script: "gen.js" });
            }
        }
    });
    let tags = [];
    doc.select("#bookInfo tr.label a").forEach(a => tags.push(cleanText(a.text())));

    let updated = "";
    let em = doc.select("#bookInfo dt.tit em").first();
    if (em) updated = cleanText(em.text()).replace(/^更新[:：]\s*/, "");

    let latestFree = "", latestVip = "";
    doc.select("a[href*=/chapter/" + id + "/]").forEach(a => {
        let prev = a.previousSibling() ? String(a.previousSibling().toString()) : "";
        if (!latestFree && prev.indexOf("最新免费章节") >= 0) latestFree = cleanText(a.text());
        if (!latestVip && prev.indexOf("最新vip章节") >= 0) latestVip = cleanText(a.text());
    });

    let detail = [];
    if (author) detail.push("作者：" + author);
    if (genreName) detail.push("类别：" + genreName);
    detail.push("状态：" + (ongoing ? "连载" : "完本"));
    if (tags.length) detail.push("标签：" + tags.join(" "));
    if (updated) detail.push("更新：" + updated);
    if (latestFree) detail.push("最新免费：" + latestFree);
    if (latestVip) detail.push("最新VIP：" + latestVip);

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: desc,
        detail: detail.join("<br>"),
        ongoing: ongoing,
        genres: genres,
        host: BASE_URL,
        url: url
    });
}
