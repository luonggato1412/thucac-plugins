load("config.js");

function execute(key, page) {
    if (!page) page = "1";
    let url = SEARCH_URL + "/search.xhtml?c.st=0&c.q=" + encodeURIComponent(key) + "&page=" + page;
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Tìm kiếm thất bại");

    let data = [];
    let seen = {};
    doc.select("div.textlist").forEach(item => {
        let a = item.select("div.textmiddle dt a[href*=/book/]").first();
        if (!a) return;  // author card
        let id = bookId(a.attr("href"));
        if (!id || seen[id]) return;
        seen[id] = true;
        let author = "", genre = "";
        item.select("li.bq span").forEach(s => {
            let t = cleanText(s.text());
            if (t.indexOf("作者") === 0) author = t.replace(/^作者[:：]\s*/, "");
            if (t.indexOf("类别") === 0) genre = t.replace(/^类别[:：]\s*/, "");
        });
        let intro = "";
        item.select("li").forEach(li => {
            if (li.select("strong").text().indexOf("简介") >= 0) intro = cleanText(li.select("p").text());
        });
        data.push({
            name: cleanText(a.text()),
            link: bookUrl(id),
            cover: fixCover(item.select("div.textleft img").attr("src"), id),
            description: [author, genre].filter(x => x).join(" | ") + (intro ? " - " + intro.substring(0, 60) : ""),
            host: BASE_URL
        });
    });
    return Response.success(data, nextPageNum(doc, page));
}
