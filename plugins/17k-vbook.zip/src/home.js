function execute() {
    let base = "/top/refactor/top100/";
    let tops = [
        ["06_vipclick/06_click_freeBook_top_100_pc.html", "免费榜"],
        ["18_popularityListScore/18_popularityListScore_top_100_pc.html", "人气榜"],
        ["01_subscribe/01_subscribe__top_100_pc.html", "畅销榜"],
        ["06_vipclick/06_vipclick_serialWithLong_top_100_pc.html", "作品点击榜"],
        ["06_vipclick/06_vipclick_cnl_man_top_100_pc.html", "男生作品榜"],
        ["06_vipclick/06_vipclick_cnl_mm_top_100_pc.html", "女生作品榜"],
        ["06_vipclick/06_vipclick_new_top_100_pc.html", "新作品点击"],
        ["06_vipclick/06_vipclick_noSign_top_100_pc.html", "潜力作品榜"],
        ["14_recommend/14_recommend_top_100_pc.html", "推荐票榜"],
        ["10_bookshelf/10_bookshelf_top_100_pc.html", "收藏榜"],
        ["09_totalwords/09_totalwords_top_100_pc.html", "字数榜"],
        ["01_subscribe/01_subscribe_finished_top_100_pc.html", "完本订阅榜"]
    ];
    let data = [{ title: "最近更新", input: "/all/book/2_0_0_0_0_0_0_0_{page}.html", script: "gen.js" }];
    tops.forEach(t => data.push({ title: t[1], input: base + t[0], script: "gen.js" }));
    return Response.success(data);
}
