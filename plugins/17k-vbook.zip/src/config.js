let BASE_URL = "https://www.17k.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL.replace(/\/+$/, "");
    }
} catch (error) {
}

let SEARCH_URL = "https://search.17k.com";

function absUrl(url) {
    url = String(url || "").trim();
    if (!url) return "";
    if (url.startsWith("//")) return "https:" + url;
    if (url.startsWith("/")) return BASE_URL + url;
    url = url.replace(/^http:\/\//, "https://");
    return url.replace(/^https:\/\/(www|h5|m)\.17k\.com/, BASE_URL);
}

function fetchRaw(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    if (!options.headers["Referer"]) options.headers["Referer"] = BASE_URL + "/";
    let response = fetch(url.indexOf("search.17k.com") >= 0 ? url : absUrl(url), options);
    if (response.ok) return response;
    return null;
}

function fetchDoc(url, options) {
    let response = fetchRaw(url, options);
    return response ? response.html("utf-8") : null;
}

function bookId(url) {
    let m = String(url).match(/\/(?:book|list|chapter)\/(\d+)/);
    if (m) return m[1];
    m = String(url).match(/(?:bookId|bid|id)=(\d+)/);
    return m ? m[1] : null;
}

function bookUrl(id) {
    return BASE_URL + "/book/" + id + ".html";
}

function tocUrl(id) {
    return BASE_URL + "/list/" + id + ".html";
}

// cdn.static.17k.com/book/189x272/{id%100}/{(id/100)%100}/{id}.jpg
function coverUrl(id) {
    let n = parseInt(id);
    let pad = x => (x < 10 ? "0" : "") + x;
    return "https://cdn.static.17k.com/book/189x272/" + pad(n % 100) + "/" + pad(Math.floor(n / 100) % 100) + "/" + id + ".jpg-189x272";
}

function fixCover(src, id) {
    src = String(src || "").trim();
    if (!src) return id ? coverUrl(id) : "";
    if (src.startsWith("//")) return "https:" + src;
    return src.replace(/^http:\/\//, "https://");
}

function cleanText(s) {
    return String(s || "").replace(/\s+/g, " ").trim();
}

// <div class="page"> ... <a href="..."><span>下一页</span></a>
function nextPageNum(doc, page) {
    let next = null;
    doc.select("div.page a").forEach(a => {
        if (a.text().indexOf("下一页") >= 0) next = a;
    });
    if (!next) return null;
    let href = next.attr("href");
    if (!href || href.indexOf("javascript") === 0) return null;
    let m = href.match(/[?&]page=(\d+)/) || href.match(/_(\d+)\.html/);
    if (!m) return null;
    return parseInt(m[1]) > parseInt(page) ? m[1] : null;
}
