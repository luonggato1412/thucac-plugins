load("config.js");

// div.readAreaBox > div.p > p (the last p.copy is the site's watermark)
function execute(url) {
    url = absUrl(url);
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không tải được chương");

    let box = doc.select("div.readAreaBox div.p").first() || doc.select("div.readAreaBox").first();
    let lines = [];
    if (box) {
        box.select("p").forEach(p => {
            if (p.hasClass("copy")) return;
            let t = cleanText(p.text().replace(/[​-‍﻿]/g, ""));
            if (!t || /17K小说网|17k\.com|第一时间看正版/i.test(t)) return;
            lines.push(t);
        });
    }
    let vip = doc.select(".vip-content, .chapter-vip, #vipContent, .buyArea, .readAreaBox .vip, form[action*=buy]").size() > 0 ||
        doc.html().indexOf("订阅本章") >= 0 || doc.html().indexOf("购买本章") >= 0;

    if (lines.length === 0) {
        if (vip) return Response.error("Đây là chương VIP (phải trả phí trên 17k.com), plugin chỉ đọc được chương miễn phí.");
        return Response.error("Không tìm thấy nội dung chương");
    }
    let content = lines.join("<br>");
    if (vip && lines.length < 15) {
        content += "<br><br>【Chương VIP - chỉ có phần xem trước. Cần mua chương trên 17k.com để đọc tiếp.】";
    }
    return Response.success(content);
}
