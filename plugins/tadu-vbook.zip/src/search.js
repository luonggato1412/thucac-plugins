load("config.js");

// Uses Tadu mobile search JSON API: /api/v1/search/list?keyWord={key}&page={page}
function execute(key, page) {
    if (!page) page = "1";
    let pageNum = parseInt(page) || 1;
    let url = BASE_URL + "/api/v1/search/list?keyWord=" + encodeURIComponent(key) + "&page=" + pageNum;
    let json = fetchJson(url);
    if (!json || !json.data) return Response.error("Tìm kiếm thất bại");

    let html = json.data.bookList || "";
    if (!html) return Response.success([], null);

    let doc = Html.parse(html);
    let data = [];
    let seen = {};

    doc.select("a[href*=/book/]").forEach(a => {
        let id = bookId(a.attr("href"));
        if (!id || seen[id]) return;
        let name = cleanText(a.select("h2").text());
        if (!name) return;
        seen[id] = true;

        let cover = fixCover(a.select("img").attr("data-src") || a.select("img").attr("src"));
        let spanText = cleanText(a.select("div.book_detail span").text());
        let parts = spanText.split("|").map(s => cleanText(s)).filter(s => s);
        let author = parts.length > 0 ? parts[0] : "";
        let genre = parts.length > 1 ? parts[1] : "";
        let intro = cleanText(a.select("div.book_detail p").text());

        let desc = [author, genre].filter(x => x).join(" | ") + (intro ? " - " + intro.substring(0, 60) : "");
        data.push({
            name: name,
            link: bookUrl(id),
            cover: cover,
            description: desc,
            host: BASE_URL
        });
    });

    let hasNext = json.data.hasNext === 1 || json.data.hasNext === true || String(json.data.hasNext) === "1";
    return Response.success(data, (hasNext && data.length > 0) ? String(pageNum + 1) : null);
}
