function execute() {
    let sorts = [
        ["99", "东方玄幻"],
        ["103", "现代都市"],
        ["108", "历史架空"],
        ["109", "武侠仙侠"],
        ["111", "科幻末世"],
        ["113", "军事战争"],
        ["112", "游戏竞技"],
        ["128", "灵异悬疑"],
        ["107", "西方奇幻"],
        ["135", "脑洞创意"],
        ["281", "男频短篇"],
        ["129", "古代言情"],
        ["133", "幻想言情"],
        ["104", "现代言情"],
        ["105", "浪漫青春"],
        ["288", "悬疑小说"],
        ["291", "女频短篇"]
    ];
    return Response.success(sorts.map(s => ({
        title: s[1],
        input: "/category/listContinue?categoryId=" + s[0] + "&thirdCategory=0&charNum=0&sortType=15&serial=a&page={page}",
        script: "gen.js"
    })));
}
