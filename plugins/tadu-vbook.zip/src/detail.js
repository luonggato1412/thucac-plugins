load("config.js");

// Book detail for Tadu. Works for m.tadu.com/book/{id} and www.tadu.com/book/{id}/.
// Never calls a method on a possibly-null element: only Elements.text()/attr()/html()/size()
// are used, and those return ""/0 when nothing matches.
var DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");
    let mUrl = bookUrl(id);
    let pcUrl = PC_URL + "/book/" + id + "/";

    let doc = null;
    try { doc = fetchDoc(mUrl); } catch (e) { doc = null; }
    if (!hasBook(doc)) {
        let pc = null;
        try {
            pc = fetchDoc(pcUrl, { headers: { "User-Agent": DESKTOP_UA, "Referer": PC_URL + "/" } });
        } catch (e) { pc = null; }
        if (hasBook(pc)) doc = pc;
    }
    if (!hasBook(doc)) return Response.error("Không tải được trang truyện");

    try {
        return Response.success(parseDetail(doc, id, mUrl));
    } catch (e) {
        return Response.error("Không đọc được thông tin truyện: " + e);
    }
}

function txt(doc, sel) {
    return cleanText(doc.select(sel).text());
}

function firstTxt(doc, sel) {
    let els = doc.select(sel);
    if (els.size() === 0) return "";
    return cleanText(els.get(0).text());
}

function attr(doc, sel, name) {
    return cleanText(doc.select(sel).attr(name));
}

function meta(doc, prop) {
    return attr(doc, "meta[property=" + prop + "]", "content");
}

function pick() {
    for (let i = 0; i < arguments.length; i++) {
        let v = cleanText(arguments[i]);
        if (v) return v;
    }
    return "";
}

function hasBook(doc) {
    if (!doc) return false;
    return !!pick(txt(doc, "div.bookname"), attr(doc, "div.bookNm a.bkNm", "data-name"),
        txt(doc, "div.bookNm a.bkNm"), meta(doc, "og:novel:book_name"));
}

function decodeEntities(s) {
    return String(s || "")
        .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
        .replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&amp;/g, "&");
}

// Keeps the line breaks of the synopsis (jsoup text() would collapse them).
function multiline(doc, sel) {
    let raw = String(doc.select(sel).html() || "");
    if (!raw) return "";
    return raw.split(/\r?\n|<br\s*\/?>|<\/p>/i)
        .map(line => cleanText(decodeEntities(line.replace(/<[^>]*>/g, ""))))
        .filter(line => line)
        .join("<br>");
}

function parseDetail(doc, id, url) {
    let name = pick(txt(doc, "div.bookname"), attr(doc, "div.bookNm a.bkNm", "data-name"),
        txt(doc, "div.bookNm a.bkNm"), meta(doc, "og:novel:book_name"));

    let author = pick(txt(doc, "div.bookauthor a"), txt(doc, "div.bookauthor"),
        txt(doc, "div.bookNm span.author").replace(/\s*著\s*$/, ""),
        txt(doc, "div.authorInfo a.author span"), meta(doc, "og:novel:author"));

    let cover = fixCover(pick(attr(doc, "div.bookcover img", "data-src"),
        attr(doc, "div.bookCover img", "data-src"), meta(doc, "og:image")));
    if (cover && !/^https?:\/\//.test(cover)) cover = "";   // og:image on m. is the placeholder "书封"
    if (cover.indexOf("coverBg.jpg") >= 0) cover = "";

    // Mobile: "完结 · 东方玄幻 · 755.5万字"
    let stateText = txt(doc, "div.bookstate");
    let stateParts = stateText.split(/[·•]/).map(s => cleanText(s)).filter(s => s);
    let status = pick(stateParts.length > 0 ? stateParts[0] : "", txt(doc, "div.bookCover span.lz"),
        meta(doc, "og:novel:status"));
    let ongoing = status.indexOf("完结") === -1 && status.indexOf("完本") === -1;

    let genreName = pick(meta(doc, "og:novel:category"), stateParts.length >= 2 ? stateParts[1] : "");

    let wordCount = stateParts.length >= 3 ? stateParts[2] : "";
    if (!wordCount) {
        let w = firstTxt(doc, "div.datum span em");
        if (w) wordCount = w + "字";
    }

    let popularity = firstTxt(doc, "div.popularity span");
    if (!popularity) {
        let pops = doc.select("div.datum span");
        if (pops.size() >= 2) popularity = cleanText(pops.get(1).text());
    }

    let tags = [];
    doc.select("div.sortList a").forEach(a => {
        let t = cleanText(a.text());
        if (t && t !== "无标签") tags.push(t);
    });

    let desc = pick(multiline(doc, "div.bookbrief"), multiline(doc, "p.intro"));
    if (!desc) desc = meta(doc, "og:description").replace(/^简介[:：]\s*/, "");

    let updated = txt(doc, "div.catalogue div.title")
        .replace(/^目录\s*/, "")
        .replace(/^更新时间[:：]\s*/, "");
    if (!updated) updated = firstTxt(doc, "div.newChapter em");

    let latest = pick(firstTxt(doc, "div.catalogue_list a"), firstTxt(doc, "div.newChapter a"),
        meta(doc, "og:novel:latest_chapter_name"));

    let genres = [];
    if (genreName) {
        let catId = CATEGORY_MAP[genreName] || "0";
        genres.push({
            title: genreName,
            input: "/category/listContinue?categoryId=" + catId + "&thirdCategory=0&charNum=0&sortType=15&serial=a&page={page}",
            script: "gen.js"
        });
    }

    let detail = [];
    if (author) detail.push("作者：" + author);
    if (genreName) detail.push("类别：" + genreName);
    detail.push("状态：" + (ongoing ? "连载" : "完结"));
    if (wordCount) detail.push("字数：" + wordCount);
    if (popularity) detail.push("人气：" + popularity);
    if (tags.length > 0) detail.push("标签：" + tags.join("、"));
    if (updated) detail.push("更新：" + updated);
    if (latest) detail.push("最新：" + latest);

    return {
        name: name,
        cover: cover,
        author: author,
        description: desc,
        detail: detail.join("<br>"),
        ongoing: ongoing,
        genres: genres,
        host: BASE_URL,
        url: url
    };
}
