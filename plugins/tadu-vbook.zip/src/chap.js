load("config.js");

// Tadu chapter pages embed the actual content URL in <input type="hidden" id="bookPartResourceUrl" value="...">
// On mobile (m.tadu.com), it points to /_book_part/{hash} (full chapter) or /_book_part_half/{hash} (preview).
// On PC (www.tadu.com), it points to /getPartContentByCodeTable/{bookId}/{seq}.
function execute(url) {
    url = absUrl(url).replace(/\/+$/, "");
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Không tải được trang chương");

    let resourceUrl = doc.select("input#bookPartResourceUrl").attr("value");
    let canRead = doc.select("input#canReadFlag").attr("value");
    if (resourceUrl && resourceUrl.startsWith("/")) resourceUrl = BASE_URL + resourceUrl;
    let rawHtml = "";
    let isPreview = false;

    if (resourceUrl) {
        isPreview = resourceUrl.indexOf("_book_part_half") >= 0;
        let json = fetchJson(resourceUrl, { headers: { "Referer": url, "X-Requested-With": "XMLHttpRequest" } });
        if (json) {
            if (json.data && json.data.content) {
                rawHtml = json.data.content;
            } else if (json.content) {
                rawHtml = json.content;
            }
        }
    }

    if (!rawHtml) {
        rawHtml = doc.select("#partContent").html();
    }

    if (!rawHtml) {
        if (canRead === "0") return Response.error("Chương này bị khóa trên web Tadu (cần đọc trên App Tadu / mua chương)");
        return Response.error("Không tìm thấy nội dung chương");
    }

    let contentDoc = Html.parse(rawHtml);
    let lines = [];
    contentDoc.select("p").forEach(p => {
        let t = cleanText(p.text().replace(/[\u200b-\u200f\ufeff]/g, ""));
        if (!t) return;
        if (/原文.*塔.*读|塔读小说|大家给我投票吧，一定不会辜负大家的期待/i.test(t)) return;
        lines.push(t);
    });

    if (lines.length === 0) {
        let plain = cleanText(contentDoc.text());
        if (plain) lines.push(plain);
    }

    if (lines.length === 0) {
        return Response.error("Nội dung chương trống");
    }

    let content = lines.join("<br>");
    if (isPreview && lines.length < 15) {
        content += "<br><br>【Chương giới hạn đọc thử trên web Tadu (từ chương 31 trở đi trang web yêu cầu đọc trên App Tadu).】";
    }
    return Response.success(content);
}
