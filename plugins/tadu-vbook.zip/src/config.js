let BASE_URL = "https://m.tadu.com";
let PC_URL = "https://www.tadu.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL.replace(/\/+$/, "");
    }
} catch (error) {
}

let MOBILE_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

let CATEGORY_MAP = {
    "东方玄幻": "99",
    "现代都市": "103",
    "历史架空": "108",
    "武侠仙侠": "109",
    "科幻末世": "111",
    "军事战争": "113",
    "游戏竞技": "112",
    "灵异悬疑": "128",
    "西方奇幻": "107",
    "脑洞创意": "135",
    "短篇小说": "281",
    "古代言情": "129",
    "幻想言情": "133",
    "现代言情": "104",
    "浪漫青春": "105",
    "悬疑小说": "288"
};

function absUrl(url) {
    url = String(url || "").trim();
    if (!url) return "";
    if (url.startsWith("//")) return "https:" + url;
    if (url.startsWith("/")) return BASE_URL + url;
    url = url.replace(/^http:\/\//, "https://");
    return url.replace(/^https:\/\/(www|m)\.tadu\.com/, BASE_URL);
}

function fetchRaw(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    if (!options.headers["User-Agent"]) options.headers["User-Agent"] = MOBILE_UA;
    if (!options.headers["Referer"]) options.headers["Referer"] = BASE_URL + "/";
    let target = url.startsWith("http") ? url : absUrl(url);
    let response = fetch(target, options);
    if (response && response.ok) return response;
    return null;
}

function fetchDoc(url, options) {
    let response = fetchRaw(url, options);
    return response ? response.html("utf-8") : null;
}

function fetchJson(url, options) {
    let response = fetchRaw(url, options);
    if (!response) return null;
    // Read the body only once: /_book_part/ responses have no Content-Type,
    // and the body cannot be read a second time after a failed response.json().
    let txt = "";
    try {
        txt = String(response.text() || "");
    } catch (e) {
        return null;
    }
    txt = txt.replace(/^\ufeff/, "");
    try {
        let m = txt.match(/^\s*[\w$.]+\(([\s\S]*)\)\s*;?\s*$/);
        return JSON.parse(m ? m[1] : txt);
    } catch (err) {
        let c = txt.match(/"content"\s*:\s*"((?:\\.|[^"\\])*)"/);
        if (c) {
            try { return { content: JSON.parse('"' + c[1] + '"') }; } catch (e2) {}
        }
        return null;
    }
}

function bookId(url) {
    let m = String(url).match(/\/book\/(?:catalogue\/|catalog\/)?(\d+)/);
    if (m) return m[1];
    m = String(url).match(/(?:bookId|bid|id)=(\d+)/);
    return m ? m[1] : null;
}

function bookUrl(id) {
    return BASE_URL + "/book/" + id;
}

function tocUrl(id, pgNum) {
    if (!pgNum) pgNum = 1;
    return BASE_URL + "/book/catalog/" + id + "?pgNum=" + pgNum + "&soutFlag=0";
}

function fixCover(src) {
    src = String(src || "").trim();
    if (!src || src.indexOf("defaultBook.png") >= 0) return "";
    if (src.startsWith("//")) return "https:" + src;
    if (src.startsWith("/")) return "https://media3.tadu.com" + src;
    return src.replace(/^http:\/\//, "https://");
}

function cleanText(s) {
    return String(s || "").replace(/[\u00a0\s]+/g, " ").trim();
}
