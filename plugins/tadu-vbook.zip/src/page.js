load("config.js");

// Mobile catalog is paginated into 100-chapter pages (/book/catalog/{id}?pgNum=1..N&soutFlag=0).
function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");
    let firstUrl = tocUrl(id, 1);
    let doc = fetchDoc(firstUrl);
    if (!doc) return Response.error("Không tải được danh sách trang mục lục");

    let totalPages = doc.select("select#chapter option").size();
    if (!totalPages || totalPages < 1) totalPages = 1;

    let pages = [];
    for (let i = 1; i <= totalPages; i++) {
        pages.push(tocUrl(id, i));
    }
    return Response.success(pages);
}
