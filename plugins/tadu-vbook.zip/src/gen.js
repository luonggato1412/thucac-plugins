load("config.js");

// Supports both /category/listContinue and /rank/listContinue JSON endpoints (0-based page)
// as well as full HTML pages containing a.bookInfo cards.
function execute(url, page) {
    if (!page) page = "1";
    let pageNum = parseInt(page) || 1;
    let apiPage = Math.max(0, pageNum - 1);
    let targetUrl = url.replace("{page}", String(apiPage));

    if (targetUrl.indexOf("listContinue") >= 0) {
        let json = fetchJson(targetUrl);
        if (!json || !json.data) return Response.error("Không tải được danh sách");
        let html = json.data.content || "";
        if (!html) return Response.success([], null);
        let doc = Html.parse(html);
        let data = parseBookCards(doc);
        let hasNext = json.data.hasNext === true || json.data.hasNext === 1 || String(json.data.hasNext) === "true";
        return Response.success(data, (hasNext && data.length > 0) ? String(pageNum + 1) : null);
    }

    let doc = fetchDoc(targetUrl);
    if (!doc) return Response.error("Không tải được danh sách");
    return Response.success(parseBookCards(doc), null);
}

function parseBookCards(doc) {
    let data = [];
    let seen = {};
    doc.select("a.bookInfo, a[href*=/book/]").forEach(a => {
        let id = bookId(a.attr("href"));
        if (!id || seen[id]) return;
        let name = cleanText(a.select("h2").text());
        if (!name) return;
        seen[id] = true;

        let cover = fixCover(a.select("img").attr("data-src") || a.select("img").attr("src"));
        let meta = cleanText(a.select("div.info > div").text()).replace(/\s*·\s*/g, " | ");
        let intro = cleanText(a.select("div.info > p").text());
        let rankMetric = cleanText(a.select("span.number").text());
        let rankLabel = cleanText(a.select("span.numberItct").text());

        let descParts = [];
        if (meta) descParts.push(meta);
        if (rankMetric) descParts.push((rankLabel ? rankLabel + ": " : "") + rankMetric);
        if (intro) descParts.push(intro.substring(0, 60));

        data.push({
            name: name,
            link: bookUrl(id),
            cover: cover,
            description: descParts.join(" - "),
            host: BASE_URL
        });
    });
    return data;
}
