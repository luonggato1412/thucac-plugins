load("config.js");

// Supports both mobile catalog pages (/book/catalog/{id}?pgNum=N)
// and PC full catalog page (www.tadu.com/book/catalogue/{id}).
function execute(url) {
    let id = bookId(url);
    if (!id) return Response.error("Link truyện không hợp lệ");

    let target = url.indexOf("/book/catalog") >= 0 ? absUrl(url) : tocUrl(id, 1);
    let doc = fetchDoc(target);
    if (!doc) return Response.error("Không tải được mục lục");

    let data = [];
    let seen = {};

    // 1. Mobile catalog: ul.chapter_ul > li > a[href*=/book/]
    doc.select("ul.chapter_ul li").forEach(li => {
        let a = li.select("a[href*=/book/]");
        if (a.size() === 0) return;
        let href = cleanText(a.attr("href"));
        let m = href.match(/\/book\/(\d+)\/(\d+)/);
        if (!m || seen[m[2]]) return;
        seen[m[2]] = true;

        let name = cleanText(a.select("p").text() || a.text());
        let vip = a.select("i").size() > 0;

        data.push({
            name: vip ? name + " [VIP]" : name,
            url: BASE_URL + "/book/" + m[1] + "/" + m[2],
            pay: vip,
            host: BASE_URL
        });
    });

    // 2. Fallback for PC full catalogue: div.directory div.chapter a[href*=/book/]
    if (data.length === 0) {
        doc.select("div.directory div.chapter a[href*=/book/]").forEach(a => {
            let href = cleanText(a.attr("href"));
            let m = href.match(/\/book\/(\d+)\/(\d+)/);
            if (!m || seen[m[2]]) return;
            seen[m[2]] = true;
            let name = cleanText(a.text());
            data.push({
                name: name,
                url: BASE_URL + "/book/" + m[1] + "/" + m[2],
                pay: false,
                host: BASE_URL
            });
        });
    }

    return Response.success(data);
}
