function execute() {
    let items = [
        ["最近更新", "/category/listContinue?categoryId=0&thirdCategory=0&charNum=0&sortType=0&serial=a&page={page}"],
        ["最新发布", "/category/listContinue?categoryId=0&thirdCategory=0&charNum=0&sortType=14&serial=a&page={page}"],
        ["男频人气榜", "/rank/listContinue?readLike=0&countType=hour72&categoryId=0&chars=0&page={page}"],
        ["男频新书榜", "/rank/listContinue?readLike=0&countType=potential&categoryId=0&chars=0&page={page}"],
        ["男频银票榜", "/rank/listContinue?readLike=0&countType=votes&categoryId=0&chars=0&page={page}"],
        ["男频互动榜", "/rank/listContinue?readLike=0&countType=interactive&categoryId=0&chars=0&page={page}"],
        ["男频完本榜", "/rank/listContinue?readLike=0&countType=wholebook&categoryId=0&chars=0&page={page}"],
        ["女频人气榜", "/rank/listContinue?readLike=3&countType=hour72&categoryId=0&chars=0&page={page}"],
        ["女频新书榜", "/rank/listContinue?readLike=3&countType=potential&categoryId=0&chars=0&page={page}"],
        ["女频银票榜", "/rank/listContinue?readLike=3&countType=votes&categoryId=0&chars=0&page={page}"],
        ["女频完本榜", "/rank/listContinue?readLike=3&countType=wholebook&categoryId=0&chars=0&page={page}"],
        ["周人气作品", "/category/listContinue?categoryId=0&thirdCategory=0&charNum=0&sortType=12&serial=a&page={page}"],
        ["完本精品", "/category/listContinue?categoryId=0&thirdCategory=0&charNum=0&sortType=15&serial=f&page={page}"]
    ];
    return Response.success(items.map(it => ({
        title: it[0],
        input: it[1],
        script: "gen.js"
    })));
}
