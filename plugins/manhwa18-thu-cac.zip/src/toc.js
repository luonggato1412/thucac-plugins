load("common.js");

function execute(url) {
    var doc = getDoc(url);
    if (doc == null) return Response.error("Không tải được danh sách chương");
    var as = doc.select("ul.list-chapters a[href]");
    var data = [];
    for (var i = 0; i < as.size(); i++) {
        var a = as.get(i);
        var name = a.select(".chapter-name").text() || a.attr("title") || a.text();
        data.push({name: name.trim(), url: abs(a.attr("href")), host: HOST});
    }
    // Site lists newest first; reader wants oldest first.
    data.reverse();
    return Response.success(data);
}
