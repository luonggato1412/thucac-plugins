load("common.js");

function execute(key, page) {
    return listPage(HOST + "/tim-kiem?q=" + encodeURIComponent(key), page);
}
