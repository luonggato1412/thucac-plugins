load("common.js");

function execute(url, page) {
    return listPage(url, page);
}
