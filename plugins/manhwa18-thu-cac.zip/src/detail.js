load("common.js");

function info(doc, label) {
    var items = doc.select(".series-information .info-item");
    for (var i = 0; i < items.size(); i++) {
        var it = items.get(i);
        var n = it.select(".info-name").text().replace(/:\s*$/, "").trim();
        if (n.toLowerCase() == label.toLowerCase()) return it.select(".info-value").first();
    }
    return null;
}

function execute(url) {
    var doc = getDoc(url);
    if (doc == null) return Response.error("Không tải được truyện");
    var name = doc.select(".series-name").text();
    var cover = "";
    var c = doc.select(".series-cover .content").first();
    if (c) {
        var m = /url\(['"]?([^'")]+)/.exec(c.attr("style"));
        if (m) cover = abs(m[1]);
    }
    var author = info(doc, "Author");
    var status = info(doc, "Status");
    var other = info(doc, "Other name");
    var genreEl = info(doc, "Genre");
    var genres = [], tags = [];
    if (genreEl) {
        var as = genreEl.select("a");
        for (var i = 0; i < as.size(); i++) {
            var t = as.get(i).text().trim();
            tags.push(t);
            genres.push({title: t, input: abs(as.get(i).attr("href")) + "?sort=update", script: "gen.js"});
        }
    }
    var st = status ? status.text().trim() : "";
    var detail = [];
    if (other && other.text()) detail.push("Tên khác: " + other.text());
    if (author && author.text()) detail.push("Tác giả: " + author.text());
    if (st) detail.push("Trạng thái: " + st);
    var views = doc.select(".statistic-item").last();
    if (views && /view/i.test(views.select(".statistic-name").text())) detail.push("Lượt xem: " + views.select(".statistic-value").text());
    if (tags.length) detail.push("Thể loại: " + tags.join(", "));
    return Response.success({
        name: name,
        cover: cover,
        author: author ? author.text() : "",
        description: doc.select(".summary-content").html(),
        detail: detail.join("<br>"),
        category: tags.join(", "),
        genres: genres,
        ongoing: !/complete|end/i.test(st),
        host: HOST,
        nsfw: true
    });
}
