var HOST = "https://manhwa18.com";

function abs(u) {
    if (!u) return "";
    u = ("" + u).trim();
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u;
    return HOST + (u.charAt(0) == "/" ? "" : "/") + u;
}

function getDoc(url) {
    return Http.get(url).headers({"Referer": HOST + "/"}).html();
}

function withPage(url, p) {
    if (p <= 1) return url;
    url = url.replace(/([?&])page=\d+&?/, "$1").replace(/[?&]$/, "");
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + "page=" + p;
}

function listBooks(doc) {
    var data = [];
    var items = doc.select("div.thumb-item-flow");
    for (var i = 0; i < items.size(); i++) {
        var it = items.get(i);
        var a = it.select(".series-title a").first();
        if (a == null) continue;
        var bg = it.select("[data-bg]").first();
        var last = it.select(".chapter-title a").first();
        data.push({
            name: a.attr("title") || a.text(),
            link: abs(a.attr("href")),
            cover: bg ? abs(bg.attr("data-bg")) : "",
            description: last ? last.text() : "",
            host: HOST
        });
    }
    return data;
}

function nextPage(doc, p) {
    var last = p;
    var links = doc.select(".pagination_wrap a[href]");
    for (var i = 0; i < links.size(); i++) {
        var m = /[?&]page=(\d+)/.exec(links.get(i).attr("href"));
        if (m && parseInt(m[1]) > last) last = parseInt(m[1]);
    }
    return p < last ? ("" + (p + 1)) : null;
}

function listPage(url, page) {
    var p = parseInt(page || "1") || 1;
    var doc = getDoc(withPage(url, p));
    if (doc == null) return Response.error("Không tải được trang");
    return Response.success(listBooks(doc), nextPage(doc, p));
}
