var HOST = "https://manhwa18.com";

function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: HOST + "/manga-list?sort=update", script: "gen.js"},
        {title: "Manhwa mới cập nhật", input: HOST + "/genre/manhwa?sort=update", script: "gen.js"},
        {title: "Raw", input: HOST + "/genre/raw?sort=update", script: "gen.js"},
        {title: "Truyện mới", input: HOST + "/manga-list?sort=new", script: "gen.js"},
        {title: "Xem nhiều", input: HOST + "/manga-list?sort=top", script: "gen.js"},
        {title: "Yêu thích", input: HOST + "/manga-list?sort=like", script: "gen.js"},
        {title: "Hoàn thành", input: HOST + "/manga-list?sort=update&completed=1", script: "gen.js"}
    ]);
}
