load("common.js");

function pushUniq(arr, u) {
    if (!u) return;
    u = ("" + u).trim().split(/\s+/)[0];
    if (!u || /loading|placeholder|\.gif(\?|$)|^data:/i.test(u)) return;
    u = abs(u);
    if (arr.indexOf(u) < 0) arr.push(u);
}

function execute(url) {
    var doc = getDoc(url);
    if (doc == null) {
        sleep(800);
        doc = getDoc(url);
    }
    if (doc == null) return Response.error("Không tải được chương");
    var imgs = doc.select("#chapter-content img");
    var data = [];
    for (var i = 0; i < imgs.size(); i++) {
        var im = imgs.get(i);
        var c = [];
        pushUniq(c, im.attr("data-src"));
        pushUniq(c, im.attr("data-original"));
        pushUniq(c, im.attr("data-lazy-src"));
        pushUniq(c, im.attr("data-cdn"));
        pushUniq(c, im.attr("src"));
        pushUniq(c, im.attr("srcset"));
        if (!c.length) continue;
        var link = c[0];
        var fb = c.slice(1);
        // Ảnh trên min.manhwa18.net rất nặng (0,7-3 MB) nên hay đứt giữa chừng:
        // cho app thử lại chính link đó thêm 2 lần trước khi báo lỗi.
        fb.push(link);
        fb.push(link);
        data.push({link: link, fallback: fb});
    }
    if (!data.length) return Response.error("Chương không có ảnh");
    return Response.success(data);
}
