load("common.js");

function execute(url) {
    var doc = getDoc(url);
    if (doc == null) return Response.error("Không tải được chương");
    var imgs = doc.select("#chapter-content img");
    var data = [];
    for (var i = 0; i < imgs.size(); i++) {
        var im = imgs.get(i);
        var src = im.attr("data-src") || im.attr("data-original") || im.attr("src");
        if (!src || /loading|\.gif$/i.test(src)) continue;
        data.push(abs(src));
    }
    if (!data.length) return Response.error("Chương không có ảnh");
    return Response.success(data);
}
