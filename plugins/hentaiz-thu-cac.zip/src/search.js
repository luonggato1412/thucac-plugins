load('config.js');

function execute(key, page) {
    if (!page) page = '1';

    var searchUrl = BASE_URL + '/browse?q=' + encodeURIComponent(key) + '&page=' + page;
    var response = fetchPage(searchUrl);
    if (!response.ok) return Response.success([]);

    return parseEpisodes(response.text(), page);
}
