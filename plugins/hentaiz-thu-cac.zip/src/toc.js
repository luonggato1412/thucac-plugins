load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    var response = fetchPage(url);
    if (!response.ok) return Response.success([]);

    var html = response.text();
    if (!html) return Response.success([]);

    var ep = null;
    var kitData = extractKitData(html);
    if (kitData && Array.isArray(kitData.data)) {
        for (var i = 0; i < kitData.data.length; i++) {
            var node = kitData.data[i];
            if (node && node.data && node.data.episode) {
                ep = node.data.episode;
                break;
            }
        }
    }

    var title = ep ? ep.title : '';
    var currentSlug = ep ? ep.slug : '';

    // If title was not found from kitData, try from title tag or ld+json
    if (!title) {
        var titleMatch = html.match(/<title>([^<]+)<\/title>/i);
        if (titleMatch) {
            title = titleMatch[1].replace(/\s*-\s*Xem Phim.*$/i, '').replace(/\s*\|\s*HentaiZ.*$/i, '').trim();
        }
    }

    var list = [];
    var seen = {};

    // Search for all episodes of this series
    if (title) {
        var searchUrl = BASE_URL + '/browse?q=' + encodeURIComponent(title);
        var sResponse = fetchPage(searchUrl);
        if (sResponse.ok) {
            var sHtml = sResponse.text();
            var sKitData = extractKitData(sHtml);
            var searchEpisodes = [];

            if (sKitData && Array.isArray(sKitData.data)) {
                for (var j = 0; j < sKitData.data.length; j++) {
                    var sNode = sKitData.data[j];
                    if (sNode && sNode.data && Array.isArray(sNode.data.episodes)) {
                        searchEpisodes = sNode.data.episodes;
                        break;
                    }
                }
            }

            // Fallback regex search if sKitData empty
            if (searchEpisodes.length === 0) {
                var p = /id:"([^"]+)",title:"([^"]+)",slug:"([^"]+)",episodeNumber:(\d+)/g;
                var m;
                while ((m = p.exec(sHtml)) !== null) {
                    searchEpisodes.push({
                        id: m[1],
                        title: m[2],
                        slug: m[3],
                        episodeNumber: parseInt(m[4], 10)
                    });
                }
            }

            var cleanTarget = title.trim().toLowerCase();
            var matched = [];

            searchEpisodes.forEach(function (item) {
                if (!item || !item.slug) return;
                var itemTitle = (item.title || '').trim().toLowerCase();
                if (itemTitle === cleanTarget && !seen[item.slug]) {
                    seen[item.slug] = true;
                    matched.push(item);
                }
            });

            if (matched.length > 0) {
                // Sort ascending by episodeNumber
                matched.sort(function (a, b) {
                    return (a.episodeNumber || 1) - (b.episodeNumber || 1);
                });

                matched.forEach(function (item) {
                    list.push({
                        name: 'Tập ' + (item.episodeNumber || 1),
                        url: BASE_URL + '/watch/' + item.slug,
                        host: BASE_URL
                    });
                });
            }
        }
    }

    // Fallback: single episode from URL
    if (list.length === 0) {
        var epNum = ep && ep.episodeNumber ? ep.episodeNumber : 1;
        list.push({
            name: 'Tập ' + epNum,
            url: url,
            host: BASE_URL
        });
    }

    return Response.success(list);
}
