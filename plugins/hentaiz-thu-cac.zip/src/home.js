load('config.js');

function execute() {
    return Response.success([
        { title: "🔥 MỚI CẬP NHẬT", input: BASE_URL + "/browse?sort=publishedAt_desc", script: "gen.js" },
        { title: "⭐ KHÔNG CHE (UNCENSORED)", input: BASE_URL + "/browse?contentRating=UNCENSORED", script: "gen.js" },
        { title: "🎬 3D HENTAI", input: BASE_URL + "/browse?animationType=THREE_D", script: "gen.js" },
        { title: "🎨 2D HENTAI", input: BASE_URL + "/browse?animationType=TWO_D", script: "gen.js" },
        { title: "👑 TOP NGÀY", input: BASE_URL + "/ranking/hentai#daily", script: "gen.js" },
        { title: "👑 TOP TUẦN", input: BASE_URL + "/ranking/hentai#weekly", script: "gen.js" },
        { title: "👑 TOP THÁNG", input: BASE_URL + "/ranking/hentai#monthly", script: "gen.js" },
        { title: "👑 TOP MÙA", input: BASE_URL + "/ranking/hentai#season", script: "gen.js" },
        { title: "❤️ TOP YÊU THÍCH", input: BASE_URL + "/ranking/hentai#likes", script: "gen.js" },
        { title: "💬 TOP BÌNH LUẬN", input: BASE_URL + "/ranking/hentai#comments", script: "gen.js" }
    ]);
}
