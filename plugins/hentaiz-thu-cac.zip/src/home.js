load('config.js');

function execute() {
    return Response.success([
        { title: "🔥 MỚI CẬP NHẬT", input: BASE_URL + "/browse?sort=publishedAt_desc", script: "gen.js" },
        { title: "⭐ KHÔNG CHE (UNCENSORED)", input: BASE_URL + "/browse?contentRating=UNCENSORED", script: "gen.js" },
        { title: "🎬 3D HENTAI", input: BASE_URL + "/browse?animationType=THREE_D", script: "gen.js" },
        { title: "🎨 2D HENTAI", input: BASE_URL + "/browse?animationType=TWO_D", script: "gen.js" },
        { title: "👑 BẢNG XẾP HẠNG", input: BASE_URL + "/ranking/hentai", script: "gen.js" }
    ]);
}
