load('config.js');

function execute(input) {
    var data = {};
    try {
        data = JSON.parse(input);
    } catch (e) {
        data = { url: input, type: 'auto' };
    }

    var streamUrl = data.url || input;
    var streamType = data.type || 'auto';
    var referer = data.referer || DEFAULT_REFERER;

    return Response.success({
        data: streamUrl,
        type: streamType,
        headers: {
            'Referer': referer,
            'User-Agent': BASE_UA
        }
    });
}
