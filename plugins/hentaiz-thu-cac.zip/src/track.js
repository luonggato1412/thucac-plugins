load('config.js');

// v4: open the episode page in the app's hidden browser, wait for the
// Haiten player iframe (watch?v=<UUID>), open that player page, find the
// plain HLS master.m3u8 it streams from and hand it to the app's own player.
// Haiten links are never built by hand.
var WATCH_RE = /(?:https?:)?\/\/[a-z0-9.-]*haiten\.org\/watch\?v=[A-Za-z0-9-]+[^"'\s<>]*/i;

function fixWatch(u) {
    u = u.replace(/&amp;/g, '&');
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.indexOf('shutup=') < 0) u += '&shutup=1';
    return u;
}

function findWatch(doc) {
    if (!doc) return '';
    var frames = doc.select('iframe');
    for (var i = 0; i < frames.size(); i++) {
        var src = frames.get(i).attr('src') || frames.get(i).attr('data-src');
        if (src && WATCH_RE.test(src)) return fixWatch(src.match(WATCH_RE)[0]);
    }
    var m = doc.html().match(WATCH_RE);
    return m ? fixWatch(m[0]) : '';
}

// The Haiten player decrypts its playlists into blob: URLs, but the same
// stream is served as plain HLS at https://cN.animez.top/<UUID>/master.m3u8
// (what the player uses on iOS). N differs per video, so read the right host
// from the requests the player already made (thumbnails.vtt, segments).
var FIND_JS = "(function(){var id=(location.search.match(/[?&]v=([0-9a-f-]{36})/i)||[])[1];" +
    "var re=/https:\\/\\/([a-z0-9-]+\\.animez\\.top)\\/([0-9a-f-]{36})\\//i,res='';" +
    "var es=performance.getEntriesByType('resource');" +
    "for(var i=0;i<es.length&&!res;i++){var n='';try{n=decodeURIComponent(es[i].name);}catch(e){n=es[i].name;}var m=n.match(re);if(m&&(!id||m[2]===id))res='https://'+m[1]+'/'+m[2]+'/master.m3u8';}" +
    "if(!res){var v=document.querySelector('video');var s=v?(v.currentSrc||v.src||''):'';if(/\\.m3u8/.test(s))res=s;}" +
    "var el=document.getElementById('tc-probe');if(!el){el=document.createElement('pre');el.id='tc-probe';el.style.display='none';document.body.appendChild(el);}el.textContent=res;})();";

var MASTER_RE = /^https:\/\/[a-z0-9.-]+\/[^\s"'<>]+\.m3u8[^\s"'<>]*$/i;

function resolveWatch(browser, url) {
    var doc = browser.launch(url, 30000);
    var w = findWatch(doc);
    for (var i = 0; i < 12 && !w; i++) {
        sleep(1500);
        w = findWatch(browser.html());
    }
    return w;
}

function directTrack(url) {
    var browser = null;
    try {
        browser = Engine.newBrowser();
        var watch = resolveWatch(browser, url);
        if (!watch) return { watch: '', stream: '' };
        browser.launch(watch, 30000);
        var stream = '';
        for (var i = 0; i < 16 && !stream; i++) {
            var doc = browser.callJs(FIND_JS, 1000);
            var s = doc ? doc.select('#tc-probe').text().trim() : '';
            if (MASTER_RE.test(s)) stream = s;
            else sleep(500);
        }
        return { watch: watch, stream: stream };
    } catch (e) {
        return { watch: '', stream: '' };
    } finally {
        try { if (browser) browser.close(); } catch (e2) {}
    }
}

// Backup when the player page gave no host: the stream lives on one of
// c1..c3.animez.top under the video UUID; take the first that answers.
function guessMaster(watch) {
    var m = /[?&]v=([0-9a-f-]{36})/i.exec(watch || '');
    if (!m) return '';
    for (var n = 1; n <= 3; n++) {
        var u = 'https://c' + n + '.animez.top/' + m[1] + '/master.m3u8';
        try {
            var r = fetch(u, { headers: { 'User-Agent': BASE_UA } });
            if (r.ok && (r.text() || '').indexOf('#EXTM3U') >= 0) return u;
        } catch (e) {}
    }
    return '';
}

function execute(input) {
    var data;
    try { data = JSON.parse(input); } catch (e) { data = { url: input }; }
    var url = normalizeUrl(data.url || input);

    var t = directTrack(url);
    var stream = t.stream || guessMaster(t.watch);
    if (!stream) {
        return Response.error(t.watch
            ? 'Không lấy được luồng video. Bấm "Tải lại" hoặc "Mở trang phim".'
            : 'Không tìm thấy trình phát trên trang tập. Bấm "Tải lại" hoặc "Mở trang phim".');
    }
    // Plain HLS (no key, no token); segments need only a browser UA.
    return Response.success({
        data: stream,
        type: 'hls',
        headers: { 'Referer': 'https://x.haiten.org/', 'User-Agent': BASE_UA }
    });
}
