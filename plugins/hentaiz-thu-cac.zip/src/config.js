var BASE_URL = 'https://hentaiz2.com';
var STORAGE_URL = 'https://storage.haiten.org';
var DEFAULT_REFERER = 'https://hentaiz2.com/';
var BASE_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

try {
    if (typeof CONFIG_URL !== 'undefined' && CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
    if (typeof CONFIG_UA !== 'undefined' && CONFIG_UA) {
        BASE_UA = CONFIG_UA;
    }
} catch (e) {}

function fetchPage(url, options) {
    if (!options) options = {};

    var headers = {
        'User-Agent': BASE_UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Referer': DEFAULT_REFERER
    };

    if (options.headers) {
        for (var key in options.headers) {
            headers[key] = options.headers[key];
        }
    }

    options.headers = headers;
    return fetch(url, options);
}

function normalizeUrl(url) {
    if (!url) return '';
    if (url.indexOf('http') === 0) return url;
    if (url.indexOf('//') === 0) return 'https:' + url;
    if (url.indexOf('/') === 0) return BASE_URL + url;
    return BASE_URL + '/' + url;
}

function cleanText(text) {
    if (!text) return '';
    return text.replace(/\s+/g, ' ').trim();
}

function extractKitData(html) {
    if (!html) return null;
    try {
        var prefix = 'kit.start(app, element,';
        var start = html.indexOf(prefix);
        if (start === -1) return null;
        var sub = html.substring(start + prefix.length);
        var firstBrace = sub.indexOf('{');
        var endMatch = sub.match(/\n\s*\}\s*\)\s*;\s*\n\s*\}\s*\)\s*;/);
        if (!endMatch) return null;
        var objStr = sub.substring(firstBrace, endMatch.index + endMatch[0].indexOf('}') + 1);
        var fn = new Function("var __sveltekit_18oy0se = { defer: function() { return null; } }; return " + objStr);
        return fn();
    } catch (e) {
        return null;
    }
}

function parseEpisodes(html, page) {
    if (!html) return Response.success([]);

    var list = [];
    var seen = {};

    // 1. Primary: Parse SvelteKit hydration data
    var kitData = extractKitData(html);
    var episodes = [];

    if (kitData && Array.isArray(kitData.data)) {
        for (var i = 0; i < kitData.data.length; i++) {
            var node = kitData.data[i];
            if (node && node.data && Array.isArray(node.data.episodes)) {
                episodes = node.data.episodes;
                break;
            }
        }
    }

    if (episodes && episodes.length > 0) {
        episodes.forEach(function (ep) {
            if (!ep || !ep.slug || seen[ep.slug]) return;
            seen[ep.slug] = true;

            var cover = '';
            if (ep.posterImage && ep.posterImage.filePath) {
                cover = STORAGE_URL + ep.posterImage.filePath;
            } else if (ep.backdropImage && ep.backdropImage.filePath) {
                cover = STORAGE_URL + ep.backdropImage.filePath;
            }

            var descParts = [];
            if (ep.animationType) {
                descParts.push(ep.animationType === 'THREE_D' ? '3D' : '2D');
            }
            if (ep.studios && Array.isArray(ep.studios)) {
                var studioNames = [];
                ep.studios.forEach(function (s) {
                    if (s && s.studio && s.studio.name) studioNames.push(s.studio.name);
                });
                if (studioNames.length > 0) descParts.push(studioNames.join(', '));
            }

            list.push({
                name: ep.title || 'Hentai',
                link: BASE_URL + '/watch/' + ep.slug,
                cover: cover,
                tag: ep.episodeNumber ? 'Tập ' + ep.episodeNumber : '',
                description: descParts.join(' • '),
                host: BASE_URL
            });
        });
    }

    // 2. Fallback: Regex extraction if SvelteKit parse returned empty
    if (list.length === 0) {
        var pattern = /id:"([^"]+)",title:"([^"]+)",slug:"([^"]+)",episodeNumber:(\d+)(?:[^{}]*filePath:"([^"]+)")?/g;
        var match;
        while ((match = pattern.exec(html)) !== null) {
            var slug = match[3];
            if (!seen[slug]) {
                seen[slug] = true;
                var poster = match[5] ? (STORAGE_URL + match[5]) : '';
                list.push({
                    name: match[2],
                    link: BASE_URL + '/watch/' + slug,
                    cover: poster,
                    tag: 'Tập ' + match[4],
                    description: '',
                    host: BASE_URL
                });
            }
        }
    }

    // Pagination: HentaiZ loads 24 items per page
    var nextPage = (list.length >= 15) ? (parseInt(page || '1', 10) + 1).toString() : null;

    return Response.success(list, nextPage);
}

var Response = {
    success: function (data, nextPage) {
        if (nextPage !== undefined) {
            return JSON.stringify({ status: 200, data: data, nextPage: nextPage });
        }
        return JSON.stringify({ status: 200, data: data });
    },
    error: function (msg) {
        return JSON.stringify({ status: 400, data: msg || 'Error' });
    }
};
