var BASE_URL = 'https://hentaiz2.com';
var STORAGE_URL = 'https://storage.haiten.org';
var DEFAULT_REFERER = 'https://hentaiz2.com/';
var BASE_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

try {
    if (typeof CONFIG_URL !== 'undefined' && CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
    if (typeof CONFIG_UA !== 'undefined' && CONFIG_UA) {
        BASE_UA = CONFIG_UA;
    }
} catch (e) {}

function fetchPage(url, options) {
    if (!options) options = {};

    var headers = {
        'User-Agent': BASE_UA,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Referer': DEFAULT_REFERER
    };

    if (options.headers) {
        for (var key in options.headers) {
            headers[key] = options.headers[key];
        }
    }

    options.headers = headers;
    return fetch(url, options);
}

function normalizeUrl(url) {
    if (!url) return '';
    if (url.indexOf('http') === 0) return url;
    if (url.indexOf('//') === 0) return 'https:' + url;
    if (url.indexOf('/') === 0) return BASE_URL + url;
    return BASE_URL + '/' + url;
}

function cleanText(text) {
    if (!text) return '';
    return text.replace(/\s+/g, ' ').trim();
}

function extractKitData(html) {
    if (!html) return null;
    try {
        var prefix = 'kit.start(app, element,';
        var start = html.indexOf(prefix);
        if (start === -1) return null;
        var sub = html.substring(start + prefix.length);
        var firstBrace = sub.indexOf('{');
        var endMatch = sub.match(/\n\s*\}\s*\)\s*;\s*\n\s*\}\s*\)\s*;/);
        if (!endMatch) return null;
        var objStr = sub.substring(firstBrace, endMatch.index + endMatch[0].indexOf('}') + 1);
        var fn = new Function("var __sveltekit_18oy0se = { defer: function() { return null; } }; return " + objStr);
        return fn();
    } catch (e) {
        return null;
    }
}

function imgUrl(img) {
    if (!img) return '';
    var p = (typeof img === 'string') ? img : (img.filePath || img.path || img.url || '');
    if (!p) return '';
    if (p.indexOf('http') === 0) return p;
    if (p.indexOf('//') === 0) return 'https:' + p;
    return STORAGE_URL + (p.charAt(0) === '/' ? '' : '/') + p;
}

function epCover(ep) {
    if (!ep) return '';
    var src = ep.episode || ep.hentai || ep;
    return imgUrl(src.posterImage) || imgUrl(src.backdropImage) ||
        imgUrl(src.cover) || imgUrl(src.thumbnail) ||
        (src !== ep ? (imgUrl(ep.posterImage) || imgUrl(ep.backdropImage)) : '');
}

function parseEpisodes(html, page) {
    if (!html) return Response.success([]);

    var list = [];
    var seen = {};
    var episodes = [];
    var paged = false;

    // 1. SvelteKit hydration data
    var kitData = extractKitData(html);
    if (kitData && Array.isArray(kitData.data)) {
        var i, d;
        // browse pages: data.episodes (paginated)
        for (i = 0; i < kitData.data.length; i++) {
            d = kitData.data[i] && kitData.data[i].data;
            if (d && Array.isArray(d.episodes) && d.episodes.length > 0) {
                episodes = d.episodes;
                paged = true;
                break;
            }
        }
        // ranking page: data.topViews.{daily,weekly,monthly,season}, one list only
        if (episodes.length === 0) {
            for (i = 0; i < kitData.data.length; i++) {
                d = kitData.data[i] && kitData.data[i].data;
                if (d && d.topViews) {
                    var keys = ['weekly', 'daily', 'monthly', 'season'];
                    for (var k = 0; k < keys.length; k++) {
                        if (Array.isArray(d.topViews[keys[k]]) && d.topViews[keys[k]].length > 0) {
                            episodes = d.topViews[keys[k]];
                            break;
                        }
                    }
                    if (episodes.length === 0 && Array.isArray(d.topLikes)) episodes = d.topLikes;
                    break;
                }
            }
        }
    }

    for (var e = 0; e < episodes.length; e++) {
        var raw = episodes[e];
        var ep = (raw && raw.episode && raw.episode.slug) ? raw.episode : raw;
        if (!ep || !ep.slug || seen[ep.slug]) continue;
        seen[ep.slug] = true;

        var descParts = [];
        if (ep.animationType) {
            descParts.push(ep.animationType === 'THREE_D' ? '3D' : '2D');
        }
        if (ep.studios && Array.isArray(ep.studios)) {
            var studioNames = [];
            for (var s = 0; s < ep.studios.length; s++) {
                var st = ep.studios[s];
                if (st && st.studio && st.studio.name) studioNames.push(st.studio.name);
            }
            if (studioNames.length > 0) descParts.push(studioNames.join(', '));
        }

        list.push({
            name: ep.title || 'Hentai',
            link: BASE_URL + '/watch/' + ep.slug,
            cover: epCover(raw),
            tag: ep.episodeNumber ? 'Tập ' + ep.episodeNumber : '',
            description: descParts.join(' • '),
            host: BASE_URL,
            _ep: ep.episodeNumber
        });
    }

    // 2. Fallback: regex on raw HTML (cover searched in the text right after each match)
    if (list.length === 0) {
        var pattern = /id:"([^"]+)",title:"([^"]+)",slug:"([^"]+)",episodeNumber:(\d+)/g;
        var match;
        while ((match = pattern.exec(html)) !== null) {
            var slug = match[3];
            if (seen[slug]) continue;
            seen[slug] = true;
            var tail = html.substring(pattern.lastIndex, pattern.lastIndex + 800);
            var nextIdx = tail.indexOf(',slug:"');
            if (nextIdx > 0) tail = tail.substring(0, nextIdx);
            var pm = tail.match(/posterImage:\{filePath:"([^"]+)"/) || tail.match(/backdropImage:\{filePath:"([^"]+)"/);
            list.push({
                name: match[2],
                link: BASE_URL + '/watch/' + slug,
                cover: pm ? imgUrl(pm[1]) : '',
                tag: 'Tập ' + match[4],
                description: '',
                host: BASE_URL,
                _ep: match[4]
            });
        }
    }

    // Same series title for different episodes: add episode number so names differ
    var titleCount = {};
    var j;
    for (j = 0; j < list.length; j++) titleCount[list[j].name] = (titleCount[list[j].name] || 0) + 1;
    for (j = 0; j < list.length; j++) {
        if (titleCount[list[j].name] > 1 && list[j]._ep) list[j].name = list[j].name + ' - Tập ' + list[j]._ep;
        delete list[j]._ep;
    }

    // Pagination: only browse pages (24/page); ranking is a single list
    var nextPage = (paged && list.length >= 15) ? (parseInt(page || '1', 10) + 1).toString() : null;

    return Response.success(list, nextPage);
}
