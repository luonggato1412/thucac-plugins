load('config.js');

// v4: chap only lists servers; the heavy work (hidden browser) runs in
// track.js when a server is picked, so the episode list opens instantly.
function server(title, mode, url) {
    return { title: title, data: JSON.stringify({ mode: mode, url: url }) };
}

function execute(url) {
    if (!url) return Response.success([]);
    url = normalizeUrl(url);
    return Response.success([
        server('Server VIP (video gốc, không quảng cáo)', 'direct', url),
        server('Server dự phòng (khung Haiten)', 'embed', url),
        server('Server Gốc (HentaiZ Web)', 'page', url)
    ]);
}
