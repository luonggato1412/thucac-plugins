load('config.js');

// v4: chap only lists servers; the heavy work (hidden browser) runs in
// track.js when a server is picked, so the episode list opens instantly.
function server(title, mode, url) {
    return { title: title, data: JSON.stringify({ mode: mode, url: url }) };
}

function execute(url) {
    if (!url) return Response.success([]);
    url = normalizeUrl(url);
    // v5: only the VIP server works in the app; the framed Haiten player and
    // the framed site page stay black, so they were dropped. If VIP fails,
    // the app's error screen offers "Mở trang phim" (full site page).
    return Response.success([
        server('Server VIP (video gốc, không quảng cáo)', 'direct', url)
    ]);
}
