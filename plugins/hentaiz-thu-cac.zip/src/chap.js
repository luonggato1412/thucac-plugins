load('config.js');

function execute(url) {
    if (!url) return Response.success([]);

    url = normalizeUrl(url);
    var response = fetchPage(url);
    if (!response.ok) return Response.success([]);

    var html = response.text();
    if (!html) return Response.success([]);

    var epId = '';
    var kitData = extractKitData(html);
    if (kitData && Array.isArray(kitData.data)) {
        for (var i = 0; i < kitData.data.length; i++) {
            var node = kitData.data[i];
            if (node && node.data && node.data.episode && node.data.episode.id) {
                epId = node.data.episode.id;
                break;
            }
        }
    }

    // Fallback: regex search for episode id
    if (!epId) {
        var m = /episode:\{id:"([^"]+)"/.exec(html);
        if (m) epId = m[1];
    }
    if (!epId) {
        var m2 = /contentId:"([^"]+)"/.exec(html);
        if (m2) epId = m2[1];
    }

    var servers = [];

    if (epId) {
        // 1. VIP Embed Player
        servers.push({
            title: 'Server VIP 1 (Haiten Player)',
            data: JSON.stringify({
                url: 'https://x.haiten.org/e/' + epId + '?shutup=1',
                type: 'auto',
                referer: BASE_URL + '/'
            })
        });

        // 2. VIP Direct Player
        servers.push({
            title: 'Server VIP 2 (Haiten Stream)',
            data: JSON.stringify({
                url: 'https://x.haiten.org/?v=' + epId + '&shutup=1',
                type: 'auto',
                referer: BASE_URL + '/'
            })
        });
    }

    // 3. Fallback: Original Web Player
    servers.push({
        title: 'Server Gốc (HentaiZ Web)',
        data: JSON.stringify({
            url: url,
            type: 'auto',
            referer: BASE_URL + '/'
        })
    });

    return Response.success(servers);
}
