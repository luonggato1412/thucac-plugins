load('config.js');

function execute(url) {
    url = normalizeUrl(url);
    var response = fetchPage(url);
    if (!response.ok) return Response.error('HTTP Error: ' + response.status);

    var html = response.text();
    if (!html) return Response.error('Could not fetch HTML');

    var ep = null;

    // 1. Primary: Extract from SvelteKit hydration data
    var kitData = extractKitData(html);
    if (kitData && Array.isArray(kitData.data)) {
        for (var i = 0; i < kitData.data.length; i++) {
            var node = kitData.data[i];
            if (node && node.data && node.data.episode) {
                ep = node.data.episode;
                break;
            }
        }
    }

    // 2. Fallback: Parse application/ld+json
    if (!ep) {
        var ldMatch = html.match(/<script\s+type="application\/ld\+json">([\s\S]*?)<\/script>/i);
        if (ldMatch) {
            try {
                var ld = JSON.parse(ldMatch[1]);
                if (ld && ld['@type'] === 'VideoObject') {
                    ep = {
                        title: ld.name,
                        description: ld.description,
                        posterImage: ld.image ? { filePath: ld.image.replace(STORAGE_URL, '') } : null
                    };
                }
            } catch (e) {}
        }
    }

    if (!ep) {
        return Response.error('Không tìm thấy thông tin phim');
    }

    var cover = '';
    if (ep.posterImage && ep.posterImage.filePath) {
        cover = ep.posterImage.filePath.indexOf('http') === 0 ? ep.posterImage.filePath : (STORAGE_URL + ep.posterImage.filePath);
    } else if (ep.backdropImage && ep.backdropImage.filePath) {
        cover = ep.backdropImage.filePath.indexOf('http') === 0 ? ep.backdropImage.filePath : (STORAGE_URL + ep.backdropImage.filePath);
    }

    var detailParts = [];
    if (ep.releaseYear) detailParts.push('Năm phát hành: ' + ep.releaseYear);
    if (ep.contentRating) detailParts.push('Phân loại: ' + (ep.contentRating === 'UNCENSORED' ? 'Không che (Uncensored)' : 'Có che'));
    if (ep.animationType) detailParts.push('Định dạng: ' + (ep.animationType === 'THREE_D' ? '3D Hentai' : '2D Hentai'));
    if (ep.viewsTotal) detailParts.push('Lượt xem: ' + ep.viewsTotal.toLocaleString());
    if (ep.studios && Array.isArray(ep.studios)) {
        var studioNames = [];
        ep.studios.forEach(function (s) {
            if (s && s.studio && s.studio.name) studioNames.push(s.studio.name);
        });
        if (studioNames.length > 0) detailParts.push('Studio: ' + studioNames.join(', '));
    }

    var genres = [];
    if (ep.genres && Array.isArray(ep.genres)) {
        ep.genres.forEach(function (g) {
            if (g && g.genre && g.genre.name && g.genre.slug) {
                genres.push({
                    title: g.genre.name,
                    input: BASE_URL + '/browse?genres=' + g.genre.slug,
                    script: 'gen.js'
                });
            }
        });
    }

    var suggests = [];
    if (genres.length > 0) {
        suggests.push({
            title: 'Cùng thể loại: ' + genres[0].title,
            input: genres[0].input,
            script: 'gen.js'
        });
    } else {
        suggests.push({
            title: 'Xem thêm Anime mới',
            input: BASE_URL + '/browse',
            script: 'gen.js'
        });
    }

    var author = 'HentaiZ';
    if (ep.studios && ep.studios.length > 0 && ep.studios[0].studio && ep.studios[0].studio.name) {
        author = ep.studios[0].studio.name;
    }

    // Clean html tags from description if needed
    var desc = ep.description || '';
    desc = desc.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();

    return Response.success({
        name: ep.title || 'HentaiZ',
        cover: cover,
        author: author,
        description: desc,
        detail: detailParts.join('<br>'),
        ongoing: false,
        genres: genres,
        suggests: suggests,
        format: 'series',
        host: BASE_URL
    });
}
