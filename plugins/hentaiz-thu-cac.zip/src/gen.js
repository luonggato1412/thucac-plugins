load('config.js');

function execute(url, page) {
    if (!page) page = '1';

    var fetchUrl = url;
    if (fetchUrl.indexOf('page=') === -1) {
        fetchUrl += (fetchUrl.indexOf('?') >= 0 ? '&' : '?') + 'page=' + page;
    }

    var response = fetchPage(fetchUrl);
    if (!response.ok) return Response.success([]);

    return parseEpisodes(response.text(), page);
}
