load('config.js');

function execute(url, page) {
    if (!page) page = '1';

    var fetchUrl = url;
    // Ranking tabs carry the list name after '#': #daily, #weekly, ...
    var hash = fetchUrl.indexOf('#');
    if (hash >= 0) {
        RANK_KEY = fetchUrl.substring(hash + 1);
        fetchUrl = fetchUrl.substring(0, hash);
    }
    if (fetchUrl.indexOf('/ranking') >= 0) {
        if (page !== '1') return Response.success([]);
    } else if (fetchUrl.indexOf('page=') === -1) {
        fetchUrl += (fetchUrl.indexOf('?') >= 0 ? '&' : '?') + 'page=' + page;
    }

    var response = fetchPage(fetchUrl);
    if (!response.ok) return Response.success([]);

    return parseEpisodes(response.text(), page);
}
