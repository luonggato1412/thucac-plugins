load("common.js");

function execute(url) {
    var p = getPage(url);
    if (p.error) return Response.error(p.error);
    var html = p.html;
    var m = /showpapercolor\.php'[\s\S]*?paperid:\s*'(\d+)',\s*vercodechk:\s*'([0-9a-fA-F]+)'/.exec(html);
    if (!m) {
        var lack = /<p>([^<]*海棠幣[^<]*不足[^<]*)<\/p>/.exec(html);
        if (lack || html.indexOf("colorpanel") < 0) {
            var price = lack ? /--\s*([\d.]+)/.exec(lack[1]) : null;
            return Response.error("Chương trả phí (VIP" + (price ? ", giá " + price[1] + " 海棠幣" : "") + "). Plugin chỉ đọc được chương miễn phí, hoặc chương bạn đã mua trên web.");
        }
        return Response.error("Không tìm thấy mã đọc chương");
    }
    var r = postPage(HOST + "/showpapercolor.php", {paperid: m[1], vercodechk: m[2]}, url);
    if (r.error) return Response.error(r.error);
    var c = r.html;
    if (c.indexOf("文章加載失敗") >= 0) return Response.error("Trang báo không tải được chương (có thể là chương trả phí). Thử lại sau.");
    c = c.replace(/<img[^>]*fullcolor[^>]*>/gi, "").replace(/<img[^>]*>/gi, "");
    c = c.replace(/(<br\s*\/?>\s*){3,}/gi, "<br><br>").trim();
    if (!c) return Response.error("Chương trống");
    return Response.success(c);
}
