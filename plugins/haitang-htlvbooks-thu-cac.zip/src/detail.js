load("common.js");

function execute(url) {
    var p = getPage(bookUrl(url));
    if (p.error) return Response.error(p.error);
    var doc = Html.parse(p.html);
    var card = null;
    var cards = doc.select("div.uk-card-default");
    for (var i = 0; i < cards.size(); i++) {
        if (cards.get(i).text().indexOf("作品編號") >= 0) { card = cards.get(i); break; }
    }
    if (card == null) return Response.error("Không đọc được trang truyện");
    var name = clean(card.select("h4").first().text());
    var status = card.select("span.uk-label").first();
    var st = status ? clean(status.text()) : "";
    var tagsEl = card.select("font[color='#800080']").first();
    var tags = [];
    if (tagsEl) {
        var parts = tagsEl.text().split("/");
        for (var t = 0; t < parts.length; t++) { var s = clean(parts[t]); if (s) tags.push(s); }
    }
    var intro = "";
    var h = card.html();
    var start = tagsEl ? h.indexOf(tagsEl.outerHtml()) : -1;
    if (start >= 0) start += tagsEl.outerHtml().length;
    var end = h.indexOf("showbooklist");
    if (end >= 0) end = h.lastIndexOf("<div", end);
    if (start >= 0 && end > start) intro = h.substring(start, end);
    intro = intro.replace(/^(\s*<br\s*\/?>)+/i, "").replace(/(<br\s*\/?>\s*)+$/i, "").trim();

    var writer = doc.select("#writerinfos h4").first();
    var authorA = writer ? writer.select("a").first() : null;
    var author = authorA ? clean(authorA.text()) : "";
    var column = "";
    if (writer) {
        var cm = /專欄：\s*([^-\s]+)/.exec(writer.text());
        if (cm) column = cm[1];
    }
    var idm = /作品編號：(\d+)/.exec(card.text());
    var detail = [];
    if (author) detail.push("Tác giả: " + author);
    if (column) detail.push("Phân khu: " + column);
    if (st) detail.push("Trạng thái: " + st);
    if (tags.length) detail.push("Nhãn: " + tags.join(", "));
    if (idm) detail.push("Mã truyện: " + idm[1]);
    var genres = [];
    return Response.success({
        name: name,
        cover: "",
        author: author,
        description: intro,
        detail: detail.join("<br>"),
        category: (column ? [column] : []).concat(tags).join(", "),
        genres: genres,
        ongoing: st.indexOf("完結") < 0,
        host: HOST,
        nsfw: true
    });
}
