var HOST = "https://www.htlvbooks.com";
var LOGIN_MSG = "Cần đăng nhập htlvbooks: mở trình duyệt trong app, vào " + HOST + "/login.php, đăng nhập rồi thử lại.";
var XHR = {"X-Requested-With": "XMLHttpRequest"};

function abs(u) {
    if (!u) return "";
    u = ("" + u).trim();
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u;
    return HOST + (u.charAt(0) == "/" ? "" : "/") + u;
}

function isLoginWall(html) {
    return /top\.location\.href\s*=\s*'\/login\.php/.test(html || "");
}

// Returns {html} or {error}.
function getPage(url, headers) {
    var h = {"Referer": HOST + "/"};
    for (var k in (headers || {})) h[k] = headers[k];
    var r = fetch(url, {headers: h});
    if (!r.ok) return {error: "Không tải được trang (HTTP " + r.status + ")"};
    var html = r.text();
    if (isLoginWall(html)) return {error: LOGIN_MSG};
    return {html: html};
}

function postPage(url, body, referer) {
    var h = {"Referer": referer || (HOST + "/"), "X-Requested-With": "XMLHttpRequest"};
    var r = fetch(url, {method: "POST", headers: h, body: body});
    if (!r.ok) return {error: "Không tải được trang (HTTP " + r.status + ")"};
    var html = r.text();
    if (isLoginWall(html)) return {error: LOGIN_MSG};
    return {html: html};
}

function clean(s) {
    return ("" + (s || "")).replace(/ /g, " ").replace(/\s+/g, " ").trim();
}

function tagText(s) {
    return clean(s).replace(/\s*\/\s*/g, " / ");
}

function param(url, name) {
    var m = new RegExp("[?&]" + name + "=([^&#]*)").exec("" + url);
    return m ? m[1] : "";
}

function bookUrl(href) {
    var u = abs(href);
    var code = param(u, "bookwritercode"), id = param(u, "bookid"), pav = param(u, "pavilionid");
    if (!id) return u;
    return HOST + "/?act=showinfo&bookwritercode=" + code + "&bookid=" + id + (pav ? "&pavilionid=" + pav : "");
}
