load("common.js");

// Rank lists: one page (up to 600 books in 3 tables), no paging.
function execute(url, page) {
    if (page && page != "1") return Response.success([], null);
    var p = getPage(url);
    if (p.error) return Response.error(p.error);
    var doc = Html.parse(p.html);
    var rows = doc.select("table tr");
    var data = [], seen = {}, last = null;
    for (var i = 0; i < rows.size(); i++) {
        var tr = rows.get(i);
        var tds = tr.select("> td");
        if (tds.size() == 0) continue;
        var a = tds.get(0).select("a[href*='bookid=']").first();
        if (a == null) {
            // VIP ranks: second row holds the tags.
            var tg = tr.select("font[color='#ADADAD']").first();
            if (last && tg && !last._tags) { last._tags = tagText(tg.text()); }
            continue;
        }
        var link = bookUrl(a.attr("href"));
        if (seen[link]) { last = null; continue; }
        seen[link] = 1;
        var tags = tds.get(0).select("font[color='#ADADAD']").first();
        var chap = tds.get(0).select("a[href*='paperid=']").first();
        var time = tds.get(0).select("font[color='#808080']").first();
        var author = tds.size() > 1 ? clean(tds.get(1).text()) : "";
        var status = tds.size() > 2 ? clean(tds.get(2).text()).replace(/^\*\s*/, "") : "";
        last = {
            name: clean(a.text()),
            link: link,
            cover: "",
            _author: author, _status: status,
            _tags: tags ? tagText(tags.text()) : "",
            _chap: chap ? clean(chap.text()) : "",
            _time: time ? clean(time.text()) : "",
            host: HOST
        };
        data.push(last);
    }
    for (var j = 0; j < data.length; j++) {
        var b = data[j], d = [];
        if (b._author) d.push(b._author);
        if (b._status) d.push(b._status);
        if (b._chap) d.push(b._chap);
        else if (b._tags) d.push(b._tags);
        if (b._time) d.push(b._time);
        data[j] = {name: b.name, link: b.link, cover: "", description: d.join(" · "), host: HOST};
    }
    return Response.success(data, null);
}
