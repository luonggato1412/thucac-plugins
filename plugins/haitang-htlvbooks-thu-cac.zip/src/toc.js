load("common.js");

function execute(url) {
    var id = param(url, "bookid");
    if (!id) return Response.error("Link truyện không có bookid");
    var r = postPage(HOST + "/showbooklist.php", {ebookid: id, showbooklisttype: "1"}, bookUrl(url));
    if (r.error) return Response.error(r.error);
    var doc = Html.parse(r.html);
    var lis = doc.select("ul li");
    var items = [], vols = 0, vol = "";
    for (var i = 0; i < lis.size(); i++) {
        var li = lis.get(i);
        var a = li.select("a[href*='paperid=']").first();
        if (a == null) {
            if (li.select("[uk-icon='folder']").size() > 0) { vol = clean(li.text()); vols++; }
            continue;
        }
        var txt = li.text();
        var pay = /\$\s*\d/.test(txt) && txt.indexOf("免費") < 0;
        items.push({name: clean(a.text()), vol: vol, url: abs(a.attr("href")), pay: pay});
    }
    var data = [];
    for (var j = 0; j < items.length; j++) {
        var it = items[j];
        var n = it.name;
        if (vols > 1 && it.vol) n = it.vol + " · " + n;
        if (it.pay) n = "🔒 " + n;
        data.push({name: n, url: it.url, host: HOST, pay: it.pay});
    }
    if (!data.length) return Response.error("Truyện chưa có chương nào");
    return Response.success(data);
}
