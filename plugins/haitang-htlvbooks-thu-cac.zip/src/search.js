load("common.js");

var FIXLANG_DEFAULT = "FsedAjjT6";

function fixlang() {
    var v = null;
    try { v = localStorage.getItem("fixlangsnd"); } catch (e) {}
    if (v) return v;
    var p = getPage(HOST + "/searchlist.php", XHR);
    if (p.error) return null;
    var m = /searchlist\('edit',\s*'([^']+)'\)/.exec(p.html);
    v = m ? m[1] : FIXLANG_DEFAULT;
    try { localStorage.setItem("fixlangsnd", v); } catch (e) {}
    return v;
}

function query(key, mode, fl) {
    var e = encodeURIComponent(key);
    return "searchmode=" + mode + "&selbooktype=all&searchkeyword=" + e +
        "&selbooktypeb=all&selsexytype=all&selages=all&selstylesa=all&selstylesb=all&selbookpoststats=all";
}

function fetchSearch(key, mode, p, fl) {
    var url;
    if (p <= 1) url = HOST + "/searchlist.php?fixlangsnd=" + fl + "&fixlangact=edit&" + query(key, mode);
    else url = HOST + "/?act=searchlist&" + query(key, mode) + "&searchkpage=" + p + "&fixlangsnd=" + fl + "&fixlangact=edit";
    var r = getPage(url, p <= 1 ? XHR : null);
    // The site allows one search every 15 s.
    if (r.html && r.html.indexOf("過於頻繁") >= 0) {
        sleep(15500);
        r = getPage(url, p <= 1 ? XHR : null);
    }
    return r;
}

function execute(key, page) {
    key = ("" + (key || "")).trim();
    var mode = "book";
    var m = /^(?:作者|tg|tác giả)\s*[:：]\s*(.+)$/i.exec(key);
    if (m) { mode = "writer"; key = m[1].trim(); }
    if (key.length < 2) return Response.error("Từ khóa phải có ít nhất 2 chữ.");
    var p = parseInt(page || "1") || 1;
    var fl = fixlang();
    if (!fl) return Response.error(LOGIN_MSG);
    var r = fetchSearch(key, mode, p, fl);
    if (r.error) return Response.error(r.error);
    if (r.html.indexOf("過於頻繁") >= 0) return Response.error("Trang chỉ cho tìm 15 giây một lần, bạn đợi chút rồi thử lại.");
    var doc = Html.parse(r.html);
    var data = [], seen = {};
    var tds = doc.select("table td");
    for (var i = 0; i < tds.size(); i++) {
        var td = tds.get(i);
        var a = td.select("a[href*='bookid=']").first();
        if (a == null) continue;
        var link = bookUrl(a.attr("href"));
        if (seen[link]) continue;
        seen[link] = 1;
        var tags = td.select("font[color='#800080']").first();
        var author = td.select("a[href*='bookwritercode']:not([href*='bookid']) font").first();
        var status = td.select("font[color='#008080']").first();
        var words = td.select("font[color='#CC33FF']").first();
        var d = [];
        if (author) d.push(clean(author.text()));
        if (status) d.push(clean(status.text()));
        if (words) d.push(clean(words.text()));
        var intro = "";
        var tn = td.textNodes();
        for (var k = tn.size() - 1; k >= 0 && !intro; k--) intro = clean(tn.get(k).text());
        if (intro) d.push(intro.length > 80 ? intro.substring(0, 80) + "…" : intro);
        else if (tags) d.push(tagText(tags.text()));
        data.push({name: clean(a.text()), link: link, cover: "", description: d.join(" · "), host: HOST});
    }
    var next = null;
    var opts = doc.select("select[name=jump] option[value]");
    for (var j = 0; j < opts.size(); j++) {
        var pm = /searchkpage=(\d+)/.exec(opts.get(j).attr("value"));
        if (pm && parseInt(pm[1]) == p + 1) next = "" + (p + 1);
    }
    return Response.success(data, next);
}
