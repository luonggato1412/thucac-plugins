var HOST = "https://www.htlvbooks.com";

function rank(t) { return HOST + "/?act=rankingall&ranktype=" + t; }

function execute() {
    return Response.success([
        {title: "耽美 mới cập nhật", input: rank("newbooklist-all"), script: "gen.js"},
        {title: "言情 mới cập nhật", input: rank("newbooklist-b-all"), script: "gen.js"},
        {title: "同人 mới cập nhật", input: rank("newbooklist-c-all"), script: "gen.js"},
        {title: "百合 mới cập nhật", input: rank("newbooklist-d-all"), script: "gen.js"},
        {title: "Chương mới hôm nay (耽美)", input: rank("newbooklist-today-a1-all"), script: "gen.js"},
        {title: "Hoàn thành", input: rank("finshbooklist-all"), script: "gen.js"},
        {title: "VIP ngày", input: rank("ranking-v-day"), script: "gen.js"},
        {title: "VIP tháng", input: rank("ranking-v-month"), script: "gen.js"},
        {title: "Độc giả đề cử tuần", input: rank("userrecommend-all"), script: "gen.js"}
    ]);
}
