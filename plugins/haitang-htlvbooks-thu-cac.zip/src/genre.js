var HOST = "https://www.htlvbooks.com";

function rank(t) { return HOST + "/?act=rankingall&ranktype=" + t; }

function execute() {
    return Response.success([
        {title: "耽美 · mới cập nhật", input: rank("newbooklist-all"), script: "gen.js"},
        {title: "耽美 · hôm nay", input: rank("newbooklist-today-a1-all"), script: "gen.js"},
        {title: "耽美 · hôm nay (2)", input: rank("newbooklist-today-a2-all"), script: "gen.js"},
        {title: "耽美 · hoàn thành", input: rank("finshbooklist-a"), script: "gen.js"},
        {title: "言情 · mới cập nhật", input: rank("newbooklist-b-all"), script: "gen.js"},
        {title: "言情 · hôm nay", input: rank("newbooklist-today-b-all"), script: "gen.js"},
        {title: "言情 · hoàn thành", input: rank("finshbooklist-b"), script: "gen.js"},
        {title: "同人 · mới cập nhật", input: rank("newbooklist-c-all"), script: "gen.js"},
        {title: "同人 · hôm nay", input: rank("newbooklist-today-c-all"), script: "gen.js"},
        {title: "同人 · hoàn thành", input: rank("finshbooklist-c"), script: "gen.js"},
        {title: "百合/輕小說 · mới cập nhật", input: rank("newbooklist-d-all"), script: "gen.js"},
        {title: "百合/輕小說 · hôm nay", input: rank("newbooklist-today-d-all"), script: "gen.js"},
        {title: "百合/輕小說 · hoàn thành", input: rank("finshbooklist-d"), script: "gen.js"},
        {title: "VIP · ngày", input: rank("ranking-v-day"), script: "gen.js"},
        {title: "VIP · tháng", input: rank("ranking-v-month"), script: "gen.js"},
        {title: "VIP · năm", input: rank("ranking-v-year"), script: "gen.js"},
        {title: "Xếp hạng · ngày", input: rank("ranking-day"), script: "gen.js"},
        {title: "Xếp hạng · tháng", input: rank("ranking-month"), script: "gen.js"},
        {title: "Xếp hạng · năm", input: rank("ranking-year"), script: "gen.js"},
        {title: "Độc giả đề cử tuần", input: rank("userrecommend-all"), script: "gen.js"}
    ]);
}
