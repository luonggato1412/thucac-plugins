load("common.js");

function execute(key, page) {
    var pn = parseInt(page || "1", 10) || 1;
    var list = [];
    if (pn === 1) {
        // Licensed anime first.
        try {
            var a = api("v2/search_v2/anime", { keyword: key, highlight: 1, pn: 1, ps: 20 });
            (a.items || []).forEach(function (c) { var b = seasonItem(c); if (b) list.push(b); });
        } catch (e) { }
    }
    var d = api("v2/search_v2", { keyword: key, highlight: 1, pn: pn, ps: 20, qid: "", sort: 0, duration_type: 0 });
    var more = false;
    (d.modules || []).forEach(function (m) {
        var items = m.items || m.data || [];
        if (m.type === "ugc") { if (items.length) more = m.has_next !== false; items.forEach(function (c) { var b = videoItem(c); if (b) list.push(b); }); }
        else if (m.type === "ogv" && pn === 1) items.forEach(function (c) {
            var b = seasonItem(c);
            if (b && !list.some(function (x) { return x.link === b.link; })) list.push(b);
        });
    });
    return Response.success(list, more ? String(pn + 1) : null);
}
