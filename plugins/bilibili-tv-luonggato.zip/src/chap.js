load("common.js");

// One server per episode; track.js turns it into a DASH stream.
function execute(url) {
    var u = parseUrl(url);
    var id = u.aid ? "aid=" + u.aid : (u.ep ? "ep_id=" + u.ep : "");
    if (!id) return Response.error("Không tìm thấy tập trong link: " + url);
    return Response.success([{ title: "Bilibili", data: id }]);
}
