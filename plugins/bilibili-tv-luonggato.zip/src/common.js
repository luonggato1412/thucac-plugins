var HOST = "https://www.bilibili.tv";
var API = "https://api.bilibili.tv/intl/gateway/web/";
var HEADERS = { "Referer": "https://www.bilibili.tv/", "Origin": "https://www.bilibili.tv", "User-Agent": UserAgent.chrome() };

// Calls a gateway API and returns its "data" (throws on error codes).
function api(path, params) {
    var q = { platform: "web", s_locale: "vi_VN" };
    if (params) for (var k in params) q[k] = params[k];
    var r = fetch(API + path, { headers: HEADERS, queries: q });
    if (!r.ok) throw "Bilibili HTTP " + r.status;
    var j = r.json();
    if (j.code !== 0) throw "Bilibili lỗi " + j.code + ": " + (j.message || "");
    return j.data || {};
}

function seasonUrl(id) { return HOST + "/vi/play/" + id; }
function videoUrl(aid) { return HOST + "/vi/video/" + aid; }

// "https://www.bilibili.tv/vi/play/2414241/30629201" -> {season: "2414241", ep: "30629201"}; video -> {aid}
function parseUrl(url) {
    var m = /\/play\/(\d+)(?:\/(\d+))?/.exec(url);
    if (m) return { season: m[1], ep: m[2] || "" };
    m = /\/video\/(\d+)/.exec(url);
    if (m) return { aid: m[1] };
    m = /[?&]ep_id=(\d+)/.exec(url);
    if (m) return { ep: m[1] };
    return {};
}

function img(u) {
    if (!u) return "";
    u = String(u);
    if (u.indexOf("//") === 0) u = "https:" + u;
    return u;
}

function text(s) { return s === undefined || s === null ? "" : String(s).replace(/<[^>]+>/g, ""); }

// Card of an anime list/search -> book item.
function seasonItem(c) {
    var id = c.season_id || c.id || c.oid;
    if (!id) return null;
    var desc = text(c.index_show || c.view || c.subtitle || c.description || c.desc || "");
    var cover = img(c.cover || c.horizontal_cover || c.vertical_cover || c.poster);
    return { name: text(c.title), link: seasonUrl(id), url: seasonUrl(id), cover: cover, description: desc, host: HOST };
}

function videoItem(c) {
    var aid = c.aid || c.oid;
    if (!aid) return null;
    var who = c.author && (c.author.nickname || c.author.name) || c.author_name || "";
    var desc = [who, text(c.duration || c.view || "")].filter(function (x) { return x; }).join(" · ");
    return { name: text(c.title), link: videoUrl(aid), url: videoUrl(aid), cover: img(c.cover), description: desc, host: HOST };
}
