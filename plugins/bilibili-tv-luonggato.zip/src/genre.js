load("common.js");

// Genres from the anime index filters (style_id).
function execute() {
    var d = api("v2/ogv/index/filters", { season_type: "1,4" });
    var out = [];
    var groups = d.filters || d.items || d.list || [];
    groups.forEach(function (g) {
        var key = g.key || g.field || g.param || "";
        if (key !== "style_id") return;
        (g.values || g.options || g.items || []).forEach(function (v) {
            var val = v.value !== undefined ? v.value : v.id;
            var name = v.name || v.title || v.label;
            if (val === undefined || val === "" || val === "-1" || val === -1 || !name) return;
            out.push({ title: text(name), input: "order=0&" + key + "=" + encodeURIComponent(val), script: "gen.js" });
        });
    });
    return Response.success(out);
}
