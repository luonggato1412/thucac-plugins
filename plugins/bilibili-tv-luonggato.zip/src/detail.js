load("common.js");

function execute(url) {
    var u = parseUrl(url);
    if (u.season) {
        var s = api("v2/ogv/play/season_info", { season_id: u.season }).season || {};
        var genres = (s.styles || []).map(function (g) {
            return { title: text(g.title || g.name), input: "order=0&style_id=" + (g.id || g.style_id), script: "gen.js" };
        });
        var info = [];
        if (s.details && s.details.desc) info.push(s.details.desc);
        var detail = [s.index_show || s.update_desc || "", s.score ? "Điểm: " + s.score : "", s.view ? "Lượt xem: " + s.view : ""]
            .concat((s.details && s.details.desc_info || []).map(function (x) { return text(x.title) + ": " + text(x.info || x.value); }))
            .filter(function (x) { return x; }).join("<br>");
        return Response.success({
            name: text(s.title),
            cover: img(s.vertical_cover || s.cover || s.horizontal_cover),
            author: text(s.publish_info || "Bilibili"),
            description: text(s.description || s.evaluate || (s.details && s.details.desc) || ""),
            detail: detail,
            ongoing: s.is_finish === undefined ? null : !s.is_finish,
            genres: genres,
            url: seasonUrl(u.season),
            host: HOST
        });
    }
    if (u.aid) {
        // User video: the page's meta tags are enough.
        var r = fetch(videoUrl(u.aid), { headers: HEADERS });
        var doc = r.ok ? r.html() : null;
        function meta(p) { if (!doc) return ""; var e = doc.select("meta[property=" + p + "], meta[name=" + p + "]").first(); return e ? e.attr("content") : ""; }
        return Response.success({
            name: text(meta("og:title")).replace(/\s*-\s*BiliBili.*$/i, "") || ("Video " + u.aid),
            cover: img(meta("og:image")),
            author: "Bilibili",
            description: text(meta("og:description") || meta("description")),
            detail: "",
            ongoing: false,
            url: videoUrl(u.aid),
            host: HOST
        });
    }
    return Response.error("Link Bilibili không hợp lệ: " + url);
}
