load("common.js");

// input: "ep_id=123" or "aid=456". Builds a DASH manifest (video + audio + Vietnamese subtitle) for the app's player.
function execute(input) {
    var m = /^(ep_id|aid)=(\d+)$/.exec(String(input || ""));
    if (!m) return Response.error("Dữ liệu tập không hợp lệ: " + input);
    var q = { device: "wap", qn: 64, tf: 0, type: 0 };
    q[m[1]] = m[2];
    var d = api("playurl", q);
    var p = d.playurl || {};
    var videos = (p.video || []).map(function (v) { return v.video_resource || v; })
        .filter(function (v) { return v && v.url; });
    if (!videos.length) return Response.error("Tập này cần đăng nhập/Premium hoặc bị chặn khu vực.");
    var avc = videos.filter(function (v) { return /^avc/.test(v.codecs || ""); });
    if (avc.length) videos = avc; // H.264 plays on every phone
    var audios = (p.audio_resource || []).filter(function (a) { return a && a.url; });
    var dur = Number(p.duration || 0) / 1000;

    var x = [];
    x.push('<?xml version="1.0" encoding="UTF-8"?>');
    x.push('<MPD xmlns="urn:mpeg:dash:schema:mpd:2011" profiles="urn:mpeg:dash:profile:isoff-on-demand:2011" type="static" minBufferTime="PT1.5S"' +
        (dur > 0 ? ' mediaPresentationDuration="PT' + dur.toFixed(3) + 'S"' : '') + '>');
    x.push('<Period>');
    x.push('<AdaptationSet contentType="video" mimeType="video/mp4" segmentAlignment="true" startWithSAP="1">');
    videos.forEach(function (v, i) { x.push(rep("v" + i, v, true)); });
    x.push('</AdaptationSet>');
    if (audios.length) {
        x.push('<AdaptationSet contentType="audio" mimeType="audio/mp4" segmentAlignment="true" startWithSAP="1">');
        audios.forEach(function (a, i) { x.push(rep("a" + i, a, false)); });
        x.push('</AdaptationSet>');
    }
    try { subtitles(m[1] === "aid" ? { aid: m[2] } : { episode_id: m[2] }, x); } catch (e) { console.log("subtitle: " + e); }
    x.push('</Period></MPD>');
    return Response.success({
        data: "data:application/dash+xml;charset=utf-8," + encodeURIComponent(x.join("\n")),
        type: "dash",
        mimeType: "application/dash+xml",
        headers: HEADERS,
        host: HOST
    });
}

function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }

function rep(id, v, video) {
    var a = ' id="' + id + '" bandwidth="' + (v.bandwidth || 1) + '"';
    if (v.codecs) a += ' codecs="' + esc(v.codecs) + '"';
    if (video) {
        if (v.width) a += ' width="' + v.width + '"';
        if (v.height) a += ' height="' + v.height + '"';
        if (v.frame_rate) a += ' frameRate="' + esc(v.frame_rate) + '"';
        if (v.sar) a += ' sar="' + esc(v.sar) + '"';
    }
    var sb = v.segment_base || {};
    var s = '<Representation' + a + '><BaseURL>' + esc(v.url) + '</BaseURL>';
    if (sb.index_range) {
        s += '<SegmentBase indexRange="' + esc(sb.index_range) + '">';
        if (sb.range) s += '<Initialization range="' + esc(sb.range) + '"/>';
        s += '</SegmentBase>';
    }
    return s + '</Representation>';
}

// Adds the Vietnamese (else English) subtitle as a WebVTT text track inside the manifest.
function subtitles(q, x) {
    var d = api("v2/subtitle", q);
    var subs = d.subtitles || [];
    if (!subs.length) return;
    var pick = null;
    ["vi", "en"].forEach(function (l) { if (!pick) pick = subs.filter(function (s) { return String(s.lang_key || "").indexOf(l) === 0; })[0]; });
    if (!pick) pick = subs[0];
    var r = fetch(img(pick.url), { headers: HEADERS });
    if (!r.ok) return;
    var body = r.text();
    var vtt = /^\s*\{/.test(body) ? jsonToVtt(JSON.parse(body)) : assToVtt(body);
    if (!vtt) return;
    var lang = String(pick.lang_key || "vi").split("-")[0];
    x.push('<AdaptationSet contentType="text" mimeType="text/vtt" lang="' + esc(lang) + '">');
    x.push('<Representation id="s0" bandwidth="256"><BaseURL>' + esc("data:text/vtt;charset=utf-8," + encodeURIComponent(vtt)) + '</BaseURL></Representation>');
    x.push('</AdaptationSet>');
}

function vttTime(sec) {
    sec = Math.max(0, Number(sec) || 0);
    var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
    function p(n, w) { n = String(n); while (n.length < w) n = "0" + n; return n; }
    return p(h, 2) + ":" + p(m, 2) + ":" + p(Math.floor(s), 2) + "." + p(Math.round((s - Math.floor(s)) * 1000) % 1000, 3);
}

function assTime(t) {
    var m = /(\d+):(\d+):(\d+)[.,](\d+)/.exec(t);
    if (!m) return 0;
    return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number("0." + m[4]);
}

function assToVtt(ass) {
    var lines = String(ass).split(/\r?\n/), fmt = null, out = ["WEBVTT", ""], inEvents = false;
    lines.forEach(function (l) {
        if (/^\[Events\]/i.test(l)) { inEvents = true; return; }
        if (/^\[/.test(l)) { inEvents = false; return; }
        if (!inEvents) return;
        if (/^Format:/i.test(l)) { fmt = l.substring(7).split(",").map(function (s) { return s.trim().toLowerCase(); }); return; }
        if (!/^Dialogue:/i.test(l) || !fmt) return;
        var parts = l.substring(9).split(",");
        var f = {};
        for (var i = 0; i < fmt.length; i++) f[fmt[i]] = i === fmt.length - 1 ? parts.slice(i).join(",") : (parts[i] || "").trim();
        var t = String(f.text || "").replace(/\{[^}]*\}/g, "").replace(/\\N/gi, "\n").replace(/\\h/g, " ").trim();
        if (!t) return;
        out.push(vttTime(assTime(f.start)) + " --> " + vttTime(assTime(f.end)));
        out.push(t.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
        out.push("");
    });
    return out.length > 2 ? out.join("\n") : "";
}

function jsonToVtt(j) {
    var out = ["WEBVTT", ""];
    (j.body || []).forEach(function (c) {
        out.push(vttTime(c.from) + " --> " + vttTime(c.to));
        out.push(String(c.content || "").replace(/&/g, "&amp;").replace(/</g, "&lt;"));
        out.push("");
    });
    return out.length > 2 ? out.join("\n") : "";
}
