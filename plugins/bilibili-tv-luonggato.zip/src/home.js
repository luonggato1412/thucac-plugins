function execute() {
    return Response.success([
        { title: "Anime thịnh hành", input: "order=0", script: "gen.js" },
        { title: "Anime mới cập nhật", input: "order=2", script: "gen.js" },
        { title: "Top anime", input: "top", script: "gen.js" },
        { title: "Video thịnh hành", input: "popular", script: "gen.js" }
    ]);
}
