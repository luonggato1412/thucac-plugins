load("common.js");

// input: "order=0&style_id=..." (anime index), "top" (top hits) or "popular" (user videos).
function execute(input, page) {
    var pn = parseInt(page || "1", 10) || 1;
    var list = [];
    if (input === "top") {
        var d = api("v2/anime/top_hits", {});
        (d.items || d.cards || d.list || []).forEach(function (c) { var b = seasonItem(c); if (b) list.push(b); });
        return Response.success(list);
    }
    if (input === "popular") {
        var p = api("v2/home/popular", { pn: pn, ps: 20 });
        var items = p.items || p.cards || p.list || [];
        items.forEach(function (c) { var b = c.season_id ? seasonItem(c) : videoItem(c); if (b) list.push(b); });
        return Response.success(list, items.length && p.has_next !== false ? String(pn + 1) : null);
    }
    var q = { season_type: "1,4", pn: pn, ps: 30 };
    String(input || "").split("&").forEach(function (kv) {
        var i = kv.indexOf("=");
        if (i > 0) q[kv.substring(0, i)] = decodeURIComponent(kv.substring(i + 1));
    });
    var r = api("v2/ogv/index/items_v2", q);
    (r.cards || r.items || []).forEach(function (c) { var b = seasonItem(c); if (b) list.push(b); });
    return Response.success(list, r.has_next ? String(pn + 1) : null);
}
