load("common.js");

function execute(url) {
    var u = parseUrl(url);
    if (u.aid) return Response.success([{ name: "Video", url: videoUrl(u.aid), host: HOST }]);
    if (!u.season) return Response.error("Link Bilibili không hợp lệ: " + url);
    var d = api("v2/ogv/play/episodes", { season_id: u.season });
    var out = [];
    (d.sections || []).forEach(function (sec) {
        (sec.episodes || []).forEach(function (e) {
            var id = e.episode_id || e.ep_id || e.id;
            if (!id) return;
            var name = text(e.title_display || e.long_title_display || e.title || ("Tập " + (out.length + 1)));
            if (e.long_title_display && name.indexOf(e.long_title_display) < 0) name += " - " + text(e.long_title_display);
            out.push({ name: name, url: seasonUrl(u.season) + "/" + id, host: HOST, pay: !!(e.label && /vip|premium/i.test(JSON.stringify(e.label))) });
        });
    });
    return Response.success(out);
}
