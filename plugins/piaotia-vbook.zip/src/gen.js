load("config.js");

function execute(url, page) {
    if (!page) page = "1";
    let doc = fetchDoc(url.replace("{page}", page));
    if (!doc) return Response.error("Không tải được danh sách");
    return Response.success(parseGrid(doc), nextPage(doc));
}
