function execute() {
    let tops = [
        ["lastupdate", "最近更新"], ["weekvisit", "周排行榜"], ["monthvisit", "月排行榜"], ["allvisit", "总排行榜"],
        ["weekvote", "周推荐榜"], ["monthvote", "月推荐榜"], ["allvote", "总推荐榜"], ["goodnum", "总收藏榜"],
        ["size", "字数排行"], ["postdate", "最新入库"]
    ];
    return Response.success(tops.map(t => ({
        title: t[1],
        input: "/booktop" + t[0] + "/0/{page}.html",
        script: "gen.js"
    })));
}
