let BASE_URL = "https://www.piaotia.com";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL.replace(/\/+$/, "");
    }
} catch (error) {
}

// The whole site is GBK (chapter pages say gb2312, which is a subset).
let CHARSET = "gbk";

function normalizeUrl(url) {
    url = String(url).replace(/^(https?:\/\/)?(www\.)?(piaotia|ptwxz|ptwwxz)\.(com|net)/, BASE_URL);
    if (url.startsWith("/")) url = BASE_URL + url;
    return url;
}

function fetchRaw(url, options) {
    options = options || {};
    options.headers = options.headers || {};
    if (!options.headers["Referer"]) options.headers["Referer"] = BASE_URL + "/";
    let response = fetch(normalizeUrl(url), options);
    if (response.ok) return response;
    return null;
}

function fetchDoc(url, options) {
    let response = fetchRaw(url, options);
    return response ? response.html(CHARSET) : null;
}

function fetchText(url, options) {
    let response = fetchRaw(url, options);
    return response ? response.text(CHARSET) : null;
}

// Book id -> [a, id], where a = floor(id / 1000)
function bookIds(url) {
    let m = String(url).match(/\/(?:bookinfo|html)\/(\d+)\/(\d+)/);
    if (m) return [m[1], m[2]];
    m = String(url).match(/(?:bid|aid|id)=(\d+)/);
    if (m) return [String(Math.floor(parseInt(m[1]) / 1000)), m[1]];
    return null;
}

function bookUrl(ids) {
    return BASE_URL + "/bookinfo/" + ids[0] + "/" + ids[1] + ".html";
}

function tocUrl(ids) {
    return BASE_URL + "/html/" + ids[0] + "/" + ids[1] + "/index.html";
}

function coverUrl(ids) {
    return BASE_URL + "/files/article/image/" + ids[0] + "/" + ids[1] + "/" + ids[1] + "s.jpg";
}

// List table used by category, ranking and search pages:
// <table class="grid"><tr><td>name</td><td>latest</td><td>author</td><td>size</td><td>date</td><td>status</td></tr>
function parseGrid(doc) {
    let data = [];
    doc.select("table.grid tr").forEach(tr => {
        let tds = tr.select("td");
        if (tds.size() < 3) return;
        let a = tds.get(0).select("a[href*=bookinfo]").first();
        if (!a) return;
        let ids = bookIds(a.attr("href"));
        if (!ids) return;
        let author = tds.get(2).text().trim();
        let latest = tds.get(1).text().trim();
        let status = tds.size() > 5 ? tds.get(5).text().trim() : "";
        let desc = [author, latest].filter(x => x).join(" | ");
        if (status) desc += " (" + status + ")";
        data.push({
            name: a.text().trim(),
            link: bookUrl(ids),
            cover: coverUrl(ids),
            description: desc,
            host: BASE_URL
        });
    });
    return data;
}

// <em id="pagestats">1/141</em>
function nextPage(doc) {
    let m = doc.select("#pagestats").text().match(/(\d+)\s*\/\s*(\d+)/);
    if (m) {
        let cur = parseInt(m[1]);
        return cur < parseInt(m[2]) ? String(cur + 1) : null;
    }
    let next = doc.select("#pagelink a.next").first();
    if (!next) return null;
    let n = next.attr("href").match(/\/(\d+)\.html|page=(\d+)/);
    return n ? (n[1] || n[2]) : null;
}
