load("config.js");

function execute(url) {
    let ids = bookIds(url);
    if (!ids) return Response.error("Link truyện không hợp lệ");
    let base = BASE_URL + "/html/" + ids[0] + "/" + ids[1] + "/";
    let doc = fetchDoc(tocUrl(ids));
    if (!doc) return Response.error("Không tải được mục lục");

    let data = [];
    let seen = {};
    doc.select(".centent li a, .mainbody li a").forEach(a => {
        let href = a.attr("href");
        let m = href.match(/(\d+)\.html$/);
        if (!m || seen[m[1]]) return;
        seen[m[1]] = true;
        data.push({
            name: a.text().trim(),
            url: base + m[1] + ".html",
            host: BASE_URL
        });
    });
    return Response.success(data);
}
