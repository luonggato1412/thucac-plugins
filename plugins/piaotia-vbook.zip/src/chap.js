load("config.js");

// Chapter pages have broken markup: the text is loose in the page between the
// ad table under the title and the "翻页上AD开始" comment, so cut it out of the raw HTML.
function execute(url) {
    url = normalizeUrl(url);
    let html = fetchText(url);
    if (!html) return Response.error("Không tải được chương");

    let body = null;
    let end = html.indexOf("<!-- 翻页上AD开始");
    if (end < 0) end = html.indexOf("<div class=\"bottomlink\"");
    if (end > 0) {
        let start = Math.max(html.lastIndexOf("</table>", end), html.lastIndexOf("class=\"toplink\"", end));
        if (start > 0) {
            body = html.substring(start, end);
            body = body.substring(body.indexOf(">") + 1);
        }
    }
    if (!body || body.replace(/<[^>]*>|&nbsp;|\s/g, "").length < 20) {
        // Fallback: use the whole page body minus the known chrome
        let doc = Html.parse(html);
        doc.select("script, style, iframe, ins, h1, table, .toplink, .bottomlink, #guild, #shop, #feit2, #Commenddiv, center, div[align=center]").remove();
        body = doc.select("body").html();
    }
    let content = clean(body);
    if (!content) return Response.error("Không tìm thấy nội dung chương");
    return Response.success(content);
}

function clean(htm) {
    return htm
        .replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<!--[\s\S]*?-->/g, "")
        .replace(/<\/?(div|center|table|tbody|tr|td|span|font|a|ins|iframe|p)[^>]*>/gi, "")
        .replace(/[^<>\n]*(飘天文学|piaotia|ptwxz|PT文学|最新章节.{0,10}网|请记住本站)[^<>\n]*/gi, "")
        .replace(/[​-‍﻿]/g, "")
        .replace(/&nbsp;/g, "")
        .replace(/\r?\n/g, "")
        .replace(/(\s*<br\s*\/?>\s*)+/gi, "<br>")
        .replace(/^(\s*<br>)+|(<br>\s*)+$/gi, "")
        .trim();
}
