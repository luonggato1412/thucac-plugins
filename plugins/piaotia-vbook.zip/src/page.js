load("config.js");

// The whole chapter list sits on one page: /html/{a}/{id}/index.html
function execute(url) {
    let ids = bookIds(url);
    if (!ids) return Response.error("Link truyện không hợp lệ");
    return Response.success([tocUrl(ids)]);
}
