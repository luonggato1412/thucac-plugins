load("config.js");

function execute(url) {
    let ids = bookIds(url);
    if (!ids) return Response.error("Link truyện không hợp lệ");
    url = bookUrl(ids);
    let html = fetchText(url);
    if (!html) return Response.error("Không tải được trang truyện");
    let doc = Html.parse(html);

    // The page has two #content blocks; the book's <h1> is the one inside #centerm
    let name = doc.select("#centerm h1").first() || doc.select("h1").first();
    name = name ? name.text().trim() : doc.select("title").text().split(/最新章节|-/)[0];

    let field = label => {
        let m = html.match(new RegExp(label + "[\\s\\S]{0,40}?：\\s*([^<]*)<"));
        return m ? m[1].replace(/&nbsp;/g, "").trim() : "";
    };
    let author = field("作(?:&nbsp;|\\s)*者");
    let genre = field("类(?:&nbsp;|\\s)*别");
    let status = field("文章状态");
    let updated = field("最后更新");
    let length = field("全文长度");

    let desc = "";
    let m = html.match(/内容简介：<\/span>([\s\S]*?)(?:<\/div>|<\/td>)/);
    if (m) {
        desc = m[1].replace(/&nbsp;/g, "").replace(/^(\s*<br\s*\/?>)+/i, "")
            .replace(/(\s*<br\s*\/?>)+\s*$/i, "").replace(/(<br\s*\/?>\s*)+/gi, "<br>").trim();
    }

    let latest = "";
    let lm = html.match(/最新章节：<\/span>\s*<a[^>]*>([^<]*)<\/a>/);
    if (lm) latest = lm[1].trim();

    let cover = doc.select("img[src*=/" + ids[1] + "s.]").attr("src");
    if (!cover) cover = coverUrl(ids);
    else if (cover.startsWith("/")) cover = BASE_URL + cover;

    let detail = [];
    if (author) detail.push("作者：" + author);
    if (genre) detail.push("类别：" + genre);
    if (status) detail.push("状态：" + status);
    if (length) detail.push("字数：" + length);
    if (updated) detail.push("更新：" + updated);
    if (latest) detail.push("最新：" + latest);

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: desc,
        detail: detail.join("<br>"),
        ongoing: status.indexOf("完成") === -1 && status.indexOf("完本") === -1,
        genres: genre ? [{ title: genre }] : [],
        host: BASE_URL,
        url: url
    });
}
