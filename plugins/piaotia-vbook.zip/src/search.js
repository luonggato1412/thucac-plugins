load("config.js");
load("gbk.js");

function execute(key, page) {
    if (!page) page = "1";
    let url = BASE_URL + "/modules/article/search.php?searchtype=articlename&searchkey=" + gbkEncode(key) + "&page=" + page;
    let doc = fetchDoc(url);
    if (!doc) return Response.error("Tìm kiếm thất bại");

    let data = parseGrid(doc);
    // A single hit may redirect straight to the book page
    if (data.length === 0 && doc.select("#content h1").size() > 0) {
        let ids = bookIds(doc.location ? doc.location() : "") ||
            bookIds(doc.select("a[href*=addbookcase.php]").attr("href"));
        if (ids) {
            data.push({
                name: doc.select("#content h1").first().text().trim(),
                link: bookUrl(ids),
                cover: coverUrl(ids),
                host: BASE_URL
            });
        }
    }
    return Response.success(data, nextPage(doc));
}
