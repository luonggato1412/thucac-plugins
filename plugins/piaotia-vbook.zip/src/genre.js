function execute() {
    let sorts = [
        ["", "全部文章"], ["1", "玄幻魔法"], ["2", "武侠修真"], ["3", "都市言情"], ["4", "历史军事"],
        ["5", "网游竞技"], ["6", "科幻小说"], ["7", "恐怖灵异"], ["8", "同人漫画"], ["9", "其他类型"]
    ];
    return Response.success(sorts.map(s => ({
        title: s[1],
        input: "/booksort" + s[0] + "/0/{page}.html",
        script: "gen.js"
    })));
}
