load("common.js");

function execute(url, page) {
    var p = getPage(withPage(url, page));
    if (p.error) return Response.error(p.error);
    var r = parseList(p.html);
    return Response.success(r.data, r.next);
}
