load("common.js");

function execute(key, page) {
    var url = HOST + "/tim-kiem?search=" + encodeURIComponent(clean(key));
    var p = getPage(withPage(url, page));
    if (p.error) return Response.error(p.error);
    var r = parseList(p.html);
    return Response.success(r.data, r.next);
}
