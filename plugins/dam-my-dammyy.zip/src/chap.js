load("common.js");

function execute(url) {
    var p = getPage(abs(url));
    if (p.error) return Response.error(p.error);
    var html = unhide(p.html).replace(/<!DOCTYPE[^>]*>/gi, "");
    var doc = Html.parse(html);
    var box = doc.select("#chapter-content-render").first();
    if (box == null) return Response.error("Không tìm thấy nội dung chương");
    // div.actcl = "open Shopee to unlock" affiliate box; the text itself is in div.actac.
    box.select("p.signature, div.actcl, script, style, iframe, ins").remove();
    // censored words "g.i.ế.t" -> "giết" (Rhino has no \p{L}, so list Vietnamese letters)
    var L = "A-Za-z\u00C0-\u024F\u1E00-\u1EFF";
    var re = new RegExp("(^|[^" + L + ".])((?:[" + L + "]\\.){2,}[" + L + "])(?![" + L + "]|\\.[" + L + "])", "g");
    var out = box.html().replace(re, function (all, pre, w) {
        return pre + w.replace(/\./g, "");
    });
    if (!clean(box.text())) return Response.error("Chương trống hoặc bị khóa");
    return Response.success(out);
}
