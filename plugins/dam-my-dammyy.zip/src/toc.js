load("common.js");

function execute(url) {
    var slug = storySlug(url);
    var p = getPage(HOST + "/" + slug + ".html");
    if (p.error) return Response.error(p.error);
    var doc = Html.parse(p.html);
    var as = doc.select("#listChapters .list-chapters .episode-title a");
    var data = [], seen = {};
    for (var i = as.size() - 1; i >= 0; i--) {
        var a = as.get(i), u = abs(a.attr("href"));
        if (seen[u]) continue;
        seen[u] = 1;
        data.push({name: clean(a.text()), url: u, host: HOST});
    }
    if (!data.length) return Response.error("Truyện chưa có chương nào");
    return Response.success(data);
}
