var HOST = "https://dammyy.cc";

function execute() {
    return Response.success([
        {title: "Truyện mới", input: HOST + "/truyen-moi.html", script: "gen.js"},
        {title: "Truyện hot", input: HOST + "/truyen-hot.html", script: "gen.js"},
        {title: "Hoàn thành", input: HOST + "/truyen-hoan-thanh.html", script: "gen.js"},
        {title: "Sáng tác", input: HOST + "/truyen-sang-tac.html", script: "gen.js"}
    ]);
}
