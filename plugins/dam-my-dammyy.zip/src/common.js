var HOST = "https://dammyy.cc";

function clean(s) {
    return ("" + (s || "")).replace(/ /g, " ").replace(/\s+/g, " ").trim();
}

function abs(u) {
    if (!u) return "";
    u = ("" + u).trim();
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u.replace(/^https?:\/\/(www\.)?dammyy\.[a-z]+/, HOST);
    return HOST + (u.charAt(0) == "/" ? "" : "/") + u;
}

// Returns {html} or {error}.
function getPage(url) {
    var r = fetch(url, {headers: {"Referer": HOST + "/"}});
    if (r.status == 404) return {error: "Truyện/chương không còn trên dammyy.cc (HTTP 404, có thể đã bị xóa)."};
    if (!r.ok) return {error: "Không tải được trang (HTTP " + r.status + ")"};
    return {html: r.text()};
}

// The site hides common words as empty <span class="x-<md5>"></span>; the word is in
// an inline <style> rule ".x-<md5>:before{content:"word"}" on the same page.
function unhide(html) {
    var map = {};
    var re = /\.([a-z]-[0-9a-f]{32}):before\s*\{\s*content:\s*"([^"]*)"/g, m;
    while ((m = re.exec(html)) != null) map[m[1]] = m[2];
    return html.replace(/<span class="([a-z]-[0-9a-f]{32})">\s*<\/span>/g, function (all, c) {
        return map[c] != null ? map[c] : "";
    });
}

// Book list cards (lists, genres, search): 24 per page.
function parseList(html) {
    var doc = Html.parse(html);
    var cards = doc.select("div.col-lg-6.col-12 div.card");
    var data = [], seen = {};
    for (var i = 0; i < cards.size(); i++) {
        var c = cards.get(i);
        var t = c.select(".story-item-title").first();
        if (t == null) continue;
        var a = t.parent().tagName() == "a" ? t.parent() : c.select("a[href]").first();
        if (a == null) continue;
        var link = abs(a.attr("href"));
        if (seen[link]) continue;
        seen[link] = 1;
        var img = c.select("img").first();
        var cover = img ? (img.attr("data-src") || img.attr("src")) : "";
        var d = [];
        if (c.select("span.is-full").size() > 0) d.push("Hoàn");
        var ch = c.select("span.chapter a").first();
        if (ch) d.push(clean(ch.text()));
        var team = c.select("div.author a").first();
        if (team) d.push(clean(team.text()));
        data.push({name: clean(t.text()), link: link, cover: abs(cover), description: d.join(" · "), host: HOST});
    }
    var next = null;
    var nx = doc.select("ul.pagination li.page-item:not(.disabled) a.page-link:has(i.bx-chevrons-right)").first();
    if (nx) {
        var pm = /[?&]page=(\d+)/.exec(nx.attr("href"));
        if (pm) next = pm[1];
    }
    return {data: data, next: next};
}

function withPage(url, page) {
    var p = parseInt(page || "1") || 1;
    if (p <= 1) return url;
    return url + (url.indexOf("?") >= 0 ? "&" : "?") + "page=" + p;
}

// /{slug}.html or /{slug}/{chapter}.html -> slug
function storySlug(url) {
    var m = /dammyy\.[a-z]+\/([^\/?#]+?)(?:\.html|\/)/.exec(abs(url));
    return m ? m[1] : "";
}
