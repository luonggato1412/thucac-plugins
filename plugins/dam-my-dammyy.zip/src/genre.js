load("common.js");

function execute() {
    var p = getPage(HOST + "/");
    if (p.error) return Response.error(p.error);
    var doc = Html.parse(p.html);
    var as = doc.select("h4.item-category a[href*='/the-loai/'], a.dropdown-item[href*='/the-loai/']");
    var data = [], seen = {};
    for (var i = 0; i < as.size(); i++) {
        var a = as.get(i), u = abs(a.attr("href")), t = clean(a.text());
        if (!t || seen[u]) continue;
        seen[u] = 1;
        data.push({title: t, input: u, script: "gen.js"});
    }
    if (!data.length) return Response.error("Không đọc được danh sách thể loại");
    return Response.success(data);
}
