load("common.js");

// The detail page has no author; the autocomplete API has it.
function findAuthor(name, slug) {
    try {
        var r = fetch(HOST + "/ajax/autocomplete?search=" + encodeURIComponent(name),
            {headers: {"Referer": HOST + "/", "X-Requested-With": "XMLHttpRequest"}});
        if (!r.ok) return "";
        var j = JSON.parse(r.text());
        var list = (j && j.data) || [];
        for (var i = 0; i < list.length; i++) if (list[i].slug == slug) return clean(list[i].author);
    } catch (e) {}
    return "";
}

function execute(url) {
    var slug = storySlug(url);
    var p = getPage(HOST + "/" + slug + ".html");
    if (p.error) return Response.error(p.error);
    var doc = Html.parse(unhide(p.html));
    var h2 = doc.select("h2.card-title[itemprop=name]").first();
    if (h2 == null) return Response.error("Không đọc được trang truyện");
    var name = clean(h2.text());
    var img = doc.select("div.col-md-3 img.img-fluid").first();
    var info = {}, genres = [];
    var dts = doc.select("dl.row > dt");
    for (var i = 0; i < dts.size(); i++) {
        var dt = dts.get(i), dd = dt.nextElementSibling();
        if (dd == null) continue;
        info[clean(dt.text())] = dd;
    }
    if (info["Thể loại"]) {
        var gs = info["Thể loại"].select("a");
        for (var g = 0; g < gs.size(); g++)
            genres.push({title: clean(gs.get(g).text()), input: abs(gs.get(g).attr("href")), script: "gen.js"});
    }
    var st = info["Trạng thái"] ? clean(info["Trạng thái"].text()) : "";
    var team = info["Team"] ? clean(info["Team"].text()) : "";
    var author = findAuthor(name, slug);
    var desc = doc.select("div.story-description div.ql-editor").first();
    var detail = [];
    if (author) detail.push("Tác giả: " + author);
    if (team) detail.push("Team: " + team);
    if (st) detail.push("Trạng thái: " + st);
    if (info["Cập nhật"]) detail.push("Cập nhật: " + clean(info["Cập nhật"].text()));
    if (info["Lượt xem"]) detail.push("Lượt xem: " + clean(info["Lượt xem"].text()));
    var cats = [];
    for (var k = 0; k < genres.length; k++) cats.push(genres[k].title);
    return Response.success({
        name: name,
        cover: img ? abs(img.attr("src")) : "",
        author: author || team,
        description: desc ? desc.html() : "",
        detail: detail.join("<br>"),
        category: cats.join(", "),
        genres: genres,
        ongoing: !/đủ bộ|hoàn/i.test(st),
        host: HOST
    });
}
