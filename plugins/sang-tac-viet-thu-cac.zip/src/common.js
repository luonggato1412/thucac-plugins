var BASE = "http://14.225.254.182";
var NOCOVER = "https://static.sangtacvietcdn.xyz/img/bookcover256.jpg";
var PER_PAGE = 48;

function clean(s) {
    return ("" + (s || "")).replace(/ /g, " ").replace(/\s+/g, " ").trim();
}

function abs(u) {
    if (!u) return "";
    u = ("" + u).trim();
    if (u.indexOf("//") == 0) return "https:" + u;
    if (u.indexOf("http") == 0) return u;
    return BASE + (u.charAt(0) == "/" ? "" : "/") + u;
}

// Any mirror (sangtacviet.vip/.com/.app, other IPs) -> this mirror.
function toBase(url) {
    url = abs(url);
    return url.replace(/^https?:\/\/[^\/]+/, BASE);
}

// /truyen/{host}/{da0}/{bookid}/[{chapter}/]
function parseBookUrl(url) {
    var m = /\/truyen\/([^\/]+)\/(\d+)\/([^\/?#]+)(?:\/([^\/?#]+))?/.exec("" + url);
    if (!m) return null;
    return {host: m[1], da0: m[2], id: m[3], chap: m[4] || ""};
}

// List/search fragment from /io/searchtp/searchBooks: a.booksearch blocks.
function searchBooks(query, page) {
    var p = page ? parseInt(page) : 1;
    if (!p || p < 1) p = 1;
    var url = BASE + "/io/searchtp/searchBooks?" + query + "&p=" + p;
    var r = fetch(url, {
        method: "POST",
        headers: {
            "Referer": BASE + "/",
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: "ignores="
    });
    if (!r.ok) return Response.error("Không tải được danh sách (HTTP " + r.status + ")");
    var doc = Html.parse(r.text());
    var items = doc.select("a.booksearch");
    var data = [];
    for (var i = 0; i < items.size(); i++) {
        var a = items.get(i);
        var img = a.select("img").first();
        var cover = img ? img.attr("src") : "";
        if (!cover) cover = NOCOVER;
        var tags = a.select("> div > span.searchtag");
        var src = tags.size() > 0 ? clean(tags.get(0).text()) : "";
        var status = tags.size() > 1 ? clean(tags.get(1).text()) : "";
        var author = clean(a.select(".searchbookauthor").text());
        var d = [];
        if (author) d.push(author);
        if (src) d.push(src);
        if (status) d.push(status);
        data.push({
            name: clean(a.select(".searchbooktitle").text()),
            link: abs(a.attr("href")),
            cover: abs(cover),
            description: d.join(" · "),
            host: BASE
        });
    }
    var next = items.size() >= PER_PAGE ? "" + (p + 1) : null;
    return Response.success(data, next);
}

function listQuery(o) {
    var q = {find: "", findinname: "", host: "", minc: "0", category: "", sort: "update", type: "", step: "", tag: ""};
    for (var k in o) q[k] = o[k];
    var parts = [];
    for (var k2 in q) parts.push(k2 + "=" + encodeURIComponent(q[k2]));
    return parts.join("&");
}
