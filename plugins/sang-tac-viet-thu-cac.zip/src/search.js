load("common.js");

function execute(key, page) {
    return searchBooks(listQuery({findinname: clean(key), sort: ""}), page);
}
