load("common.js");

function execute(input, page) {
    return searchBooks(input, page);
}
