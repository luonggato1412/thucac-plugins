load("common.js");

function execute() {
    var cats = [
        ["hh", "Huyền huyễn"], ["dt", "Đô thị"], ["nt", "Ngôn tình"], ["vd", "Võng du"],
        ["kh", "Khoa học viễn tưởng"], ["ls", "Lịch sử"], ["dn", "Đồng nhân"], ["dna", "Dị năng"],
        ["ld", "Linh dị"], ["ln", "Light Novel"]
    ];
    var hosts = ["qidian", "fanqie", "jjwxc", "ciweimao", "sfacg", "faloo", "qimao", "uukanshu"];
    var data = [];
    for (var i = 0; i < cats.length; i++)
        data.push({title: cats[i][1], input: listQuery({category: cats[i][0]}), script: "gen.js"});
    for (var j = 0; j < hosts.length; j++)
        data.push({title: "Nguồn " + hosts[j], input: listQuery({host: hosts[j]}), script: "gen.js"});
    return Response.success(data);
}
