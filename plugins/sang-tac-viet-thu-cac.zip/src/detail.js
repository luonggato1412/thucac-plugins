load("common.js");

function meta(doc, prop) {
    var m = doc.select("meta[property='" + prop + "']").first();
    return m ? clean(m.attr("content")) : "";
}

function execute(url) {
    url = toBase(url);
    var b = parseBookUrl(url);
    if (!b) return Response.error("Link truyện không đúng dạng /truyen/<nguồn>/1/<id>/");
    url = BASE + "/truyen/" + b.host + "/" + b.da0 + "/" + b.id + "/";
    var r = fetch(url, {headers: {"Referer": BASE + "/"}});
    if (!r.ok) return Response.error("Không tải được trang truyện (HTTP " + r.status + ")");
    var doc = r.html();
    var name = meta(doc, "og:novel:book_name") || clean(doc.select("#book_name2").text()) || meta(doc, "og:title");
    var author = meta(doc, "og:novel:author");
    var cover = meta(doc, "og:image") || NOCOVER;
    var status = meta(doc, "og:novel:status");
    var update = meta(doc, "og:novel:update_time");
    var cats = meta(doc, "og:novel:category");
    var ori = clean(doc.select("#oriname").text());
    var desc = doc.select("#book-sumary").html() || meta(doc, "og:description");

    var genres = [];
    if (cats) {
        var cs = cats.split(",");
        for (var i = 0; i < cs.length; i++) {
            var c = clean(cs[i]);
            if (c) genres.push({title: c, input: listQuery({find: c}), script: "gen.js"});
        }
    }
    var info = [];
    if (ori) info.push("Tên gốc: " + ori);
    info.push("Nguồn: " + b.host);
    if (status) info.push("Trạng thái: " + status);
    if (update) info.push("Cập nhật: " + update);

    return Response.success({
        name: name,
        cover: abs(cover),
        author: author,
        description: desc,
        detail: info.join("<br>"),
        ongoing: !/hoàn thành|hoàn tất|full/i.test(status),
        genres: genres,
        host: BASE
    });
}
