load("common.js");

function execute() {
    return Response.success([
        {title: "Mới cập nhật", input: listQuery({sort: "update"}), script: "gen.js"},
        {title: "Truyện mới", input: listQuery({sort: "new"}), script: "gen.js"},
        {title: "Xem nhiều hôm nay", input: listQuery({sort: "viewday"}), script: "gen.js"},
        {title: "Xem nhiều tuần", input: listQuery({sort: "viewweek"}), script: "gen.js"},
        {title: "Xem nhiều", input: listQuery({sort: "view"}), script: "gen.js"},
        {title: "Yêu thích", input: listQuery({sort: "like"}), script: "gen.js"},
        {title: "Hoàn thành", input: listQuery({sort: "update", step: "3"}), script: "gen.js"},
        {title: "Sáng tác", input: listQuery({sort: "update", type: "sangtac"}), script: "gen.js"},
        {title: "Truyện dịch", input: listQuery({sort: "update", type: "dich"}), script: "gen.js"}
    ]);
}
