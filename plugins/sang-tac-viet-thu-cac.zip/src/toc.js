load("common.js");

function execute(url) {
    var b = parseBookUrl(toBase(url));
    if (!b) return Response.error("Link truyện không đúng dạng");
    var api = BASE + "/index.php?ngmar=chapterlist&h=" + b.host + "&bookid=" + b.id + "&sajax=getchapterlist";
    var r = fetch(api, {headers: {"Referer": BASE + "/truyen/" + b.host + "/1/" + b.id + "/", "X-Requested-With": "XMLHttpRequest"}});
    if (!r.ok) return Response.error("Không tải được mục lục (HTTP " + r.status + ")");
    var txt = r.text();
    var j;
    try { j = JSON.parse(txt.substring(txt.indexOf("{"))); } catch (e) { return Response.error("Mục lục trả về không đúng định dạng"); }
    if (!j || ("" + j.code) != "1" || !j.data) return Response.error("Truyện chưa có chương (mã " + (j ? j.code : "?") + ")");
    var unlocked = {};
    try { unlocked = typeof j.unlocked == "string" ? JSON.parse(j.unlocked) : (j.unlocked || {}); } catch (e2) {}
    var items = ("" + j.data).split("-//-");
    var data = [];
    for (var i = 0; i < items.length; i++) {
        var f = items[i].split("-/-");
        if (f.length < 3 || !f[1]) continue;
        var cid = clean(f[1]);
        var flag = f.length > 3 ? clean(f[3]) : "";
        var pay = flag != "" && flag != "unvip" && !unlocked[cid];
        var name = clean(f[2]) || ("Chương " + (data.length + 1));
        data.push({
            name: (pay ? "🔒 " : "") + name,
            url: BASE + "/truyen/" + b.host + "/" + (clean(f[0]) || "1") + "/" + b.id + "/" + cid + "/",
            host: BASE,
            pay: pay
        });
    }
    // uukanshu lists newest first.
    if (b.host == "uukanshu") data.reverse();
    if (!data.length) return Response.error("Truyện chưa có chương nào");
    return Response.success(data);
}
