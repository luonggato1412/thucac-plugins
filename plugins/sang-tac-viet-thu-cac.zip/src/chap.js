load("common.js");

// Sáng Tác Việt does not load chapter text inside apps, so chapters are read from the
// original site (STV only machine-translates them) and translated by Thư Các itself.
var QD_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

function chromeMsg(url) {
    return Response.error("Sáng Tác Việt chặn đọc chương trong app, và nguồn này chưa đọc thẳng được từ trang gốc. Hãy mở chương bằng Chrome: " + url);
}

// Translate Chinese paragraphs with the app's own translator (VietPhrase).
function toVi(paras) {
    var out = [];
    var tr = Qt.translate(paras.join("\n"), "vi").translateText;
    var lines = ("" + (tr || paras.join("\n"))).split("\n");
    for (var i = 0; i < lines.length; i++) {
        var l = clean(lines[i]);
        if (l) out.push("<p>" + l.replace(/&/g, "&amp;").replace(/</g, "&lt;") + "</p>");
    }
    return out.join("");
}

function qidian(b) {
    var url = "https://m.qidian.com/chapter/" + b.id + "/" + b.chap + "/";
    var r = fetch(url, {headers: {"User-Agent": QD_UA, "Referer": "https://m.qidian.com/"}});
    if (!r.ok) return Response.error("Không tải được chương từ Qidian (HTTP " + r.status + ")");
    var html = r.text();
    var i = html.indexOf('id="vite-plugin-ssr_pageContext"');
    if (i < 0) return Response.error("Qidian trả về trang lạ, thử lại sau.");
    var st = html.indexOf(">", i) + 1, en = html.indexOf("</script>", st);
    var c;
    try { c = JSON.parse(html.substring(st, en)).pageContext.pageProps.pageData.chapterInfo; } catch (e) { c = null; }
    if (!c) return Response.error("Không đọc được dữ liệu chương Qidian");
    if (c.vipStatus == 1 && c.isBuy != 1 && c.chapterType != 2)
        return Response.success("<p>[Chương VIP] Chương này phải mua trên Qidian, plugin chỉ đọc được chương miễn phí.</p>");
    var raw = ("" + (c.content || "")).replace(/<script[\s\S]*?<\/script>/gi, "");
    var doc = Html.parse(raw);
    var ps = doc.select("p");
    var paras = [];
    for (var k = 0; k < ps.size(); k++) {
        var t = ("" + ps.get(k).text()).replace(/[​-‍﻿]/g, "").replace(/^[\s　]+/, "").trim();
        if (t) paras.push(t);
    }
    if (!paras.length) {
        var t2 = clean(doc.text());
        if (t2) paras.push(t2);
    }
    if (!paras.length) return Response.error("Không tìm thấy nội dung chương");
    var out = toVi(paras);
    if (c.fEnS || c.cES || c.randomFont) out = "<p>[Cảnh báo] Chương này bị mã hoá phông chữ ở Qidian, nội dung có thể sai.</p>" + out;
    return Response.success(out);
}

function execute(url) {
    url = toBase(url);
    var b = parseBookUrl(url);
    if (!b || !b.chap) return Response.error("Link chương không đúng dạng");
    if (b.host == "qidian") return qidian(b);
    return chromeMsg(url);
}
