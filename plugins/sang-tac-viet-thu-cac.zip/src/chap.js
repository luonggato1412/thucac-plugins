load("common.js");

// The site checks one-time cookies that the chapter page sets with its own scripts,
// so the chapter is opened in the app's hidden browser and read from the page once loaded.
function execute(url) {
    url = toBase(url);
    var b = parseBookUrl(url);
    if (!b || !b.chap) return Response.error("Link chương không đúng dạng");
    var browser = Engine.newBrowser();
    var html = "", msg = "";
    try {
        browser.launch(url, 20000);
        for (var i = 0; i < 50; i++) {
            var doc = browser.html();
            if (doc) {
                var el = doc.select("div[id^=cld-]").first();
                if (el && clean(el.text()).length > 20) { html = el.html(); break; }
                var mc = doc.select("#maincontent").first();
                var t = mc ? clean(mc.text()) : "";
                if (/đăng nhập|login/i.test(t) && t.length < 400) { msg = "Chương cần đăng nhập Sáng Tác Việt: mở trình duyệt trong app, vào " + BASE + " và đăng nhập, rồi thử lại."; break; }
                if (/captcha/i.test(t)) { msg = "Trang yêu cầu xác minh captcha: mở chương này bằng trình duyệt trong app, xác minh xong rồi thử lại."; break; }
                // "Nhấp vào để tải chương": nudge the page if it waits for a click.
                if (i == 6 || i == 20) browser.callJs("try{var m=document.getElementById('maincontent');if(m)m.click();}catch(e){}", 200);
            }
            sleep(400);
        }
    } finally {
        browser.close();
    }
    if (msg) return Response.error(msg);
    if (!html) return Response.error("Không tải được nội dung chương, thử lại sau ít giây.");
    html = html.replace(/<script[\s\S]*?<\/script>/gi, "")
        .replace(/<button[\s\S]*?<\/button>/gi, "")
        .replace(/<\/?i\b[^>]*>/gi, "");
    return Response.success(html);
}
