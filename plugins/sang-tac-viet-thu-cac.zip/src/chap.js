load("common.js");

// Sáng Tác Việt deliberately does not load chapter text inside app WebViews or automated
// browsers (its own script never sends the request), so chapters are read in Chrome instead.
function execute(url) {
    url = toBase(url);
    return Response.error("Sáng Tác Việt chặn đọc chương trong app. Hãy mở chương này bằng Chrome: " + url);
}
